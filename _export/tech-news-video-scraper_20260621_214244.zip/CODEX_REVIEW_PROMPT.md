﻿# RevisiÃƒÂ³n del proyecto Tech News Video Scraper

Analiza completamente este proyecto antes de modificar archivos.

## Contexto

Es una aplicaciÃƒÂ³n local en Python que:

- busca noticias de tecnologÃƒÂ­a e inteligencia artificial;
- filtra noticias fuera del tema;
- evita noticias repetidas mediante SQLite;
- detecta imÃƒÂ¡genes y videos;
- traduce informaciÃƒÂ³n al espaÃƒÂ±ol;
- genera cinco slides visuales;
- agrega una imagen de introducciÃƒÂ³n;
- agrega una imagen de salida;
- envÃƒÂ­a los slides a Telegram;
- guarda cada ejecuciÃƒÂ³n en una carpeta separada.

## Reglas de trabajo

1. No elimines funcionalidades que ya estÃƒÂ¡n operativas.
2. No cambies el diseÃƒÂ±o visual de los slides sin autorizaciÃƒÂ³n.
3. No expongas ni escribas tokens de Telegram.
4. Usa las variables de `.env`.
5. No incluyas `.env` en commits.
6. Revisa el cÃƒÂ³digo completo antes de proponer cambios.
7. Identifica duplicaciÃƒÂ³n, errores silenciosos y dependencias innecesarias.
8. MantÃƒÂ©n compatibilidad con Windows y PowerShell.
9. Ejecuta pruebas o validaciones antes de dar una tarea por terminada.
10. Explica quÃƒÂ© archivos cambiarÃƒÂ¡s antes de modificarlos.

## Primera tarea

Realiza primero una auditorÃƒÂ­a y entrega:

- resumen de la arquitectura actual;
- flujo completo desde la bÃƒÂºsqueda hasta Telegram;
- errores o riesgos encontrados;
- mejoras prioritarias;
- archivos que deberÃƒÂ­an modificarse;
- propuesta de implementaciÃƒÂ³n por etapas.

No modifiques todavÃƒÂ­a el cÃƒÂ³digo hasta finalizar esta auditorÃƒÂ­a.
