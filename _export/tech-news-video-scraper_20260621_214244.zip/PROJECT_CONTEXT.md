﻿# Contexto completo del proyecto

- Proyecto: tech-news-video-scraper
- Generado: 2026-06-21 21:42:46
- Total de archivos: 29
- .env fue excluido para proteger secretos.

## Estructura

~~~~text
.env.example
.gitignore
app.py
assets\intro.png
assets\out.png
config\settings.yaml
config\sources.yaml
exportar-proyecto.backup.ps1
exportar-proyecto.ps1
README.md
requirements.txt
src\__init__.py
src\card_renderer.py
src\database.py
src\exporter.py
src\media_extractor.py
src\models.py
src\ranker.py
src\scraper.py
src\source_loader.py
src\telegram_sender.py
src\topic_filter.py
src\translator.py
src\utils.py
src\video_detector.py
templates\card.html
templates\card_template.html
templates\embed_template.html
templates\index_template.html
~~~~

## Contenido de los archivos

### .env.example

~~~~text
# Copia este archivo como .env y rellena tus datos.
# El archivo .env NO se sube al repositorio (ver .gitignore).

# Activar/desactivar el envío a Telegram
TELEGRAM_ENABLED=true

# Token del bot (lo da @BotFather)
TELEGRAM_BOT_TOKEN=pon_aqui_tu_token

# ID del chat/canal destino (puedes obtenerlo con @userinfobot o getUpdates)
TELEGRAM_CHAT_ID=pon_aqui_tu_chat_id

# Enviar los 5 slides como un álbum (true) o uno por uno (false)
TELEGRAM_SEND_AS_ALBUM=true

~~~~

### .gitignore

~~~~text
# Secretos / entorno
.env

# Entornos
.venv/
venv/
__pycache__/
*.pyc

# Datos y salidas generadas
data/news.db
data/news.db-wal
data/news.db-shm
output/*/

# Playwright
.cache/

# IDE / SO
.vscode/
.idea/
.DS_Store
Thumbs.db

~~~~

### app.py

~~~~python
"""app.py — Tech News Video Scraper + generador de carruseles visuales.

Busca noticias recientes de tecnología/IA, prioriza las que tienen VIDEO,
completa con noticias de IMAGEN de alta calidad si hace falta, y genera por cada
una un slide.png 1080x1350 listo para carrusel (estilo tecnológico/premium),
además de card.html, embed.html, poster/hero, metadata y la galería index.html.

Uso:
    python app.py
    python app.py --topic "robótica" --num 5 --lang es --no-input

Respeta robots.txt; no salta paywalls/captchas/DRM. Si un video no es embebible,
NO falla: guarda el enlace + poster y usa la imagen en el slide.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.utils import load_yaml, setup_logging
from src.models import Run, Article
from src.database import Database
from src.source_loader import load_sources
from src.scraper import Scraper
from src.translator import Translator
from src.ranker import Ranker
from src.card_renderer import CardRenderer
from src.exporter import Exporter
from src.topic_filter import is_valid_tech_ai_news, log_decision
from src.telegram_sender import send_run_to_telegram

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

try:
    from rich.table import Table
    from rich.console import Console
    _console = Console()
except Exception:  # pragma: no cover
    _console = None

SETTINGS_PATH = "config/settings.yaml"
SOURCES_PATH = "config/sources.yaml"


# --------------------------------------------------------------------------- #
def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Tech News Video Scraper")
    p.add_argument("--topic", help="Tema de búsqueda")
    p.add_argument("--num", type=int, help="Número de noticias a generar")
    p.add_argument("--lang", help="Idioma de salida (por defecto es)")
    p.add_argument("--no-input", action="store_true",
                   help="No preguntar; usar valores por defecto/flags")
    return p.parse_args()


def ask_inputs(args, settings) -> tuple[str, int, str]:
    d = settings.get("defaults", {})
    def_topic = d.get("topic", "tecnología, inteligencia artificial y avances tecnológicos")
    def_num = int(d.get("num_news", 5))
    def_lang = d.get("language", "es")

    if args.no_input:
        return (args.topic or def_topic, args.num or def_num, args.lang or def_lang)

    if args.topic:
        topic = args.topic
    else:
        try:
            entered = input("¿Qué tema quieres buscar? Presiona ENTER para usar "
                            "tecnología e inteligencia artificial por defecto: ").strip()
        except EOFError:
            entered = ""
        topic = entered or def_topic

    if args.num:
        num = args.num
    else:
        try:
            raw = input(f"¿Cuántas noticias quieres? (ENTER = {def_num}): ").strip()
        except EOFError:
            raw = ""
        num = int(raw) if raw.isdigit() and int(raw) > 0 else def_num

    if args.lang:
        lang = args.lang
    else:
        try:
            raw = input(f"Idioma de salida (ENTER = {def_lang}): ").strip()
        except EOFError:
            raw = ""
        lang = raw or def_lang

    return topic, num, lang


# --------------------------------------------------------------------------- #
def _short_headline(title: str, limit: int = 85) -> str:
    title = (title or "").strip()
    if len(title) <= limit:
        return title
    cut = title[:limit].rsplit(" ", 1)[0]
    return cut.rstrip(",.;:") + "…"


def _short_caption(summary: str, limit: int = 220) -> str:
    summary = (summary or "").strip()
    if len(summary) <= limit:
        return summary
    cut = summary[:limit].rsplit(" ", 1)[0]
    return cut.rstrip(",.;:") + "…"


# --------------------------------------------------------------------------- #
def run() -> int:
    args = parse_args()
    settings = load_yaml(SETTINGS_PATH)
    log = setup_logging(settings.get("logging", {}).get("level", "INFO"))

    topic, num_target, lang = ask_inputs(args, settings)
    log.info(f"[bold cyan]Tema:[/] {topic}  |  [bold]Noticias:[/] {num_target}  |  "
             f"[bold]Idioma:[/] {lang}")

    fallback_to_image = settings.get("video", {}).get("fallback_to_image", True)

    db = Database(settings.get("database", {}).get("path", "data/news.db"))
    sources = load_sources(SOURCES_PATH, only_enabled=True)
    for s in sources:
        db.upsert_source(s.name, s.trusted, s.region, s.enabled)

    scraper = Scraper(settings)
    translator = Translator(settings)
    ranker = Ranker(settings)
    renderer = CardRenderer(settings)
    exporter = Exporter(settings, renderer=renderer, session=scraper.session)

    topic_cfg = settings.get("topic_filter", {})

    run_obj = Run(topic=topic, language=lang, requested=num_target)
    run_id = db.start_run(run_obj)

    considered = 0
    rejected_not_tech = 0
    rejected_political = 0
    discarded_no_media = 0
    skipped_duplicates = 0
    video_candidates: list[Article] = []
    image_candidates: list[Article] = []
    seen_in_run: set[str] = set()

    pool_target = max(num_target * 4, num_target + 8)

    # ---------------------- Recolección ---------------------- #
    for source in sources:
        if len(video_candidates) >= pool_target:
            break
        log.info(f"[bold]Fuente:[/] {source.name}")
        try:
            urls = scraper.collect_article_urls(source)
        except Exception as exc:
            log.warning(f"  No se pudieron listar artículos de {source.name}: {exc}")
            continue
        log.info(f"  {len(urls)} enlaces candidatos")

        for url in urls:
            if len(video_candidates) >= pool_target:
                break
            try:
                article = scraper.fetch_article(url, source, topic)
            except Exception as exc:
                log.debug(f"  Error procesando {url}: {exc}")
                continue
            if article is None:
                continue
            considered += 1

            # FILTRO TEMÁTICO DURO: si no es Tech/IA, no entra (ni BD ni export).
            valid, reason, tscore = is_valid_tech_ai_news(article.to_dict(), topic_cfg)
            log_decision(article.to_dict(), valid, reason, tscore)
            article._topic_valid = valid          # gate para el ranker
            article._topic_score = tscore
            if not valid:
                if reason == "political_general":
                    rejected_political += 1
                else:
                    rejected_not_tech += 1
                continue

            # Necesitamos al menos video o imagen para un slide decente
            if article.media_type == "none":
                discarded_no_media += 1
                continue

            if db.is_duplicate(article):
                skipped_duplicates += 1
                continue
            key = article.canonical_url or article.article_url
            if key in seen_in_run:
                skipped_duplicates += 1
                continue
            seen_in_run.add(key)

            ranker.score(article, trusted=source.trusted, is_duplicate=False,
                         published_dt=getattr(article, "_published_dt", None))
            if not ranker.passes(article):
                continue

            if article.media_type == "video":
                video_candidates.append(article)
                log.info(f"  [green]✓ VIDEO[/] (score {article.score}): "
                         f"{article.title_original[:64]}")
            else:
                image_candidates.append(article)
                log.info(f"  [cyan]✓ imagen[/] (score {article.score}): "
                         f"{article.title_original[:64]}")

    scraper.close()

    # ---------------------- Selección ---------------------- #
    best_video = Ranker.sort_best(video_candidates)
    selected = best_video[:num_target]
    if len(selected) < num_target and fallback_to_image:
        need = num_target - len(selected)
        fillers = Ranker.sort_best(image_candidates)[:need]
        if fillers:
            log.info(f"[yellow]Solo {len(selected)} con video; completando con "
                     f"{len(fillers)} de imagen de alta calidad.[/]")
        selected += fillers

    # ---------------------- Traducción + export ---------------------- #
    run_dir = exporter.make_run_dir()
    final: list[Article] = []
    items: list[dict] = []
    embed_blocked = with_video = with_image = 0

    for i, article in enumerate(selected, start=1):
        src_lang = article.language_original
        if lang.startswith("es"):
            article.title_es = translator.translate(article.title_original, src_lang)
            article.summary_es = translator.translate(article.summary_original, src_lang)
        else:
            article.title_es = article.title_original
            article.summary_es = article.summary_original
        article.short_headline_es = _short_headline(article.title_es or article.title_original)
        article.short_caption_es = _short_caption(article.summary_es or article.summary_original)

        article.run_id = run_id
        article.status = "selected"
        try:
            db.insert_article(article)
        except Exception as exc:
            log.warning(f"No se pudo guardar en BD: {exc}")

        item = exporter.export_article(run_dir, i, article)
        article.status = "exported"
        final.append(article)
        items.append(item)

        if article.media_type == "video":
            with_video += 1
        else:
            with_image += 1
        if article.embed_status == "blocked":
            embed_blocked += 1

        log.info(f"[green]Exportada[/] noticia_{i:02d} "
                 f"[{article.media_type}/{article.embed_status}] -> {item.get('folder')}")

    renderer.close()

    slides_generated = sum(1 for a in final if a.local_slide_path)
    stats = {
        "requested": num_target, "found": len(final),
        "considered": considered,
        "rejected_not_tech": rejected_not_tech,
        "rejected_political": rejected_political,
        "with_video": with_video, "with_image": with_image,
        "embed_blocked": embed_blocked, "discarded_no_media": discarded_no_media,
        "skipped_duplicates": skipped_duplicates,
        "slides_generated": slides_generated,
    }
    exporter.finalize_run(run_dir, run_id, topic, items, stats)
    db.finish_run(run_id, len(final), discarded_no_media, skipped_duplicates, str(run_dir))
    db.close()

    # --- Envío a Telegram (opcional, controlado por .env) ---
    telegram_status = send_run_to_telegram(run_dir, final)
    stats["telegram"] = telegram_status

    print_summary(topic, run_dir, stats, final, log)
    return 0


# --------------------------------------------------------------------------- #
_TELEGRAM_MSG = {
    "sent": "enviado correctamente",
    "partial": "enviado parcialmente",
    "error": "error al enviar",
    "not_configured": "no configurado (revisa .env)",
    "disabled": "desactivado (TELEGRAM_ENABLED=false)",
    "no_slides": "sin slides para enviar",
}


def print_summary(topic, run_dir, stats, final, log) -> None:
    tg = _TELEGRAM_MSG.get(stats.get("telegram", ""), stats.get("telegram", "—"))
    log.info("")
    log.info("[bold green]==================== RESUMEN FINAL ====================[/]")
    log.info(f"Noticias encontradas: {stats.get('considered', 0)}")
    log.info(f"Rechazadas por no ser tecnología/IA: {stats.get('rejected_not_tech', 0)}")
    log.info(f"Rechazadas por política/general: {stats.get('rejected_political', 0)}")
    log.info(f"Repetidas: {stats.get('skipped_duplicates', 0)}")
    log.info(f"Aceptadas finales: {stats['found']}")
    log.info(f"  · con video: {stats['with_video']}  · con imagen: {stats['with_image']}"
             f"  · embeds bloqueados: {stats['embed_blocked']}")
    log.info(f"Slides generados: {stats.get('slides_generated', 0)}")
    log.info(f"Telegram: {tg}")
    log.info(f"Carpeta: {run_dir}")
    log.info(f"Galería: {run_dir / 'index.html'}")
    if stats['found'] < stats['requested']:
        log.info(f"[yellow]Faltaron {stats['requested'] - stats['found']} noticias.[/]")

    if _console and final:
        table = Table(title="Noticias finales", show_lines=False)
        table.add_column("#", justify="right", style="cyan")
        table.add_column("Titular (ES)", style="white", overflow="fold")
        table.add_column("Fuente", style="green")
        table.add_column("Media", style="magenta")
        table.add_column("Embed", style="yellow")
        table.add_column("Score", justify="right")
        table.add_column("slide.png", justify="center")
        for i, a in enumerate(final, start=1):
            table.add_row(str(i),
                          (a.short_headline_es or a.title_es or a.title_original)[:60],
                          a.source_name, a.media_type, a.embed_status, str(a.score),
                          "✓" if a.local_slide_path else "—")
        _console.print(table)

    log.info("")
    log.info("[bold]Rutas de cada carpeta:[/]")
    for i, a in enumerate(final, start=1):
        log.info(f"  noticia_{i:02d}: {a.output_folder}")


# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    try:
        raise SystemExit(run())
    except KeyboardInterrupt:
        print("\nInterrumpido por el usuario.")
        raise SystemExit(130)

~~~~

### assets\intro.png

_Archivo binario incluido en el ZIP. TamaÃƒÂ±o: 1643028 bytes._

### assets\out.png

_Archivo binario incluido en el ZIP. TamaÃƒÂ±o: 1911156 bytes._

### config\settings.yaml

~~~~yaml
# ===========================================================================
# settings.yaml — Configuración general del Tech News Video Scraper
# Puedes editar todos estos valores sin tocar el código.
# ===========================================================================

# --- Comportamiento por defecto cuando el usuario no escribe nada ---
defaults:
  # Tema enfocado en tecnología/IA (NO usar "latest news", que trae política).
  topic: "inteligencia artificial tecnología avances tecnológicos robótica chips software innovación"
  num_news: 5            # cuántas noticias válidas queremos generar
  language: "es"         # idioma de salida (los textos finales se traducen a este idioma)

# --- Búsqueda / scraping ---
search:
  max_articles_per_source: 25   # cuántos enlaces inspeccionar como máximo por fuente
  max_age_days: 21              # descartar noticias más viejas que esto (0 = sin límite)
  request_timeout: 20           # segundos de espera por petición HTTP
  retries: 2                    # reintentos por petición
  delay_between_requests: 1.0   # pausa (segundos) entre peticiones para ser respetuosos
  respect_robots_txt: true      # respetar robots.txt cuando sea posible
  user_agent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) TechNewsVideoScraper/1.0 (+local research tool)"
  # Términos enfocados (se usan para filtrar enlaces y como referencia de búsqueda).
  query_terms_es: "inteligencia artificial tecnología avances tecnológicos robótica chips software innovación"
  query_terms_en: "artificial intelligence technology robotics chips software innovation breakthrough"
  # Combinaciones orientadas a noticias tech/IA con video (para fuentes de búsqueda).
  query_combinations:
    - "AI technology news video"
    - "artificial intelligence breakthrough video"
    - "robotics technology news video"
    - "Samsung futuristic devices video"
    - "OpenAI news video"
    - "Nvidia AI chips news video"
    - "Google AI technology news video"
    - "robots innovation video"
    - "smart devices technology video"
    - "new technology inventions video"

# --- Filtro temático OBLIGATORIO (Tech/IA). Ver src/topic_filter.py ---
topic_filter:
  enabled: true
  min_topic_score: 2
  positive_keywords:
    - inteligencia artificial
    - ia
    - ai
    - artificial intelligence
    - machine learning
    - deep learning
    - modelo de ia
    - chatbot
    - robot
    - robótica
    - tecnología
    - tech
    - software
    - hardware
    - chip
    - semiconductor
    - nvidia
    - openai
    - google ai
    - gemini
    - anthropic
    - claude
    - microsoft
    - apple intelligence
    - samsung
    - tesla
    - spacex
    - computación cuántica
    - quantum computing
    - ciberseguridad
    - cybersecurity
    - realidad virtual
    - realidad aumentada
    - startup tecnológica
    - automatización
    - dispositivo inteligente
    - wearable
    - smartphone
    - app
    - data center
    - gpu
    - robot humanoide
    - innovación tecnológica
  negative_keywords:
    - elecciones
    - presidente
    - gobierno
    - congreso
    - partido político
    - campaña electoral
    - crimen
    - asesinato
    - guerra
    - conflicto armado
    - deporte
    - fútbol
    - farándula
    - celebridad
    - religión
    - escándalo político
    - bolsa de valores
    - inflación
    # Equivalentes en inglés (muchas fuentes están en inglés antes de traducir)
    - election
    - president
    - government
    - congress
    - political party
    - war
    - football
    - soccer
    - sports
    - celebrity
    - crime
    - murder
    - stock market
    - inflation

# --- Playwright (renderizado dinámico) ---
playwright:
  enabled: true          # si es false, nunca se usa Playwright (solo requests+BS4)
  headless: true
  nav_timeout: 25000     # ms
  # Solo se usa cuando una fuente marca "needs_js: true" o cuando requests no encuentra video.

# --- Detección de video ---
video:
  require_video: true            # cada noticia DEBE tener video; si no, se descarta
  accept_types:                  # tipos de video aceptados
    - youtube
    - vimeo
    - dailymotion
    - html5            # etiqueta <video> nativa
    - og_video         # Open Graph video
    - jsonld           # VideoObject en JSON-LD
    - iframe           # iframe genérico de reproductor
  # No se descargan videos de terceros: se guarda el enlace/embed público.
  download_video: false          # por defecto NO descargar (respeto a copyright/DRM)
  check_embeddable: true         # comprobar X-Frame-Options/CSP antes de embeber
  fallback_to_image: true        # si no se completan N con video, rellenar con imagen de calidad
  download_media: true           # descargar hero_image.jpg / video_poster.jpg para el slide

# --- Traducción ---
translation:
  target_language: "es"
  # Backend: "auto" prueba lo que esté disponible. Opciones: auto | deep_translator | none
  backend: "auto"
  # API opcional. Si rellenas una clave, se usará ese servicio.
  api:
    provider: ""        # "deepl" | "google" | "" (vacío = sin API, usa fallback gratuito)
    api_key: ""
  # Si no hay ningún backend disponible, se deja el texto original (marcado como sin traducir).

# --- Ranking ---
ranking:
  min_score: 1           # puntuación mínima para que una noticia sea aceptada
  weights:
    keyword_ai: 5            # +5 IA / ML / modelos / robots / chips
    futuristic_tech: 4       # +4 tecnología futurista (cuántica, humanoides, AGI...)
    has_usable_media: 3      # +3 video o imagen usable para el slide
    has_clear_video: 3       # +3 video claro
    trusted_source: 3        # +3 fuente tecnológica confiable
    recent: 2                # +2 noticia reciente
    global_impact: 2         # +2 impacto global
    visual_devices: 2        # +2 dispositivos / avances visuales
    # Penalizaciones (refuerzan al filtro; normalmente ya se descartan antes)
    political: -10           # -10 política general
    economy_no_tech: -8      # -8 economía general sin tecnología
    tabloid_sports_crime: -10 # -10 crimen / farándula / deportes
    ambiguous_no_tech: -5    # -5 título ambiguo sin tema tech
    repeated: -10            # -10 repetida

# --- Salida ---
output:
  base_dir: "output"
  folder_prefix: "noticia_"   # se generará noticia_01, noticia_02, ...
  open_folder_when_done: false

# --- Base de datos ---
database:
  path: "data/news.db"

# --- Logs ---
logging:
  level: "INFO"          # DEBUG | INFO | WARNING | ERROR

~~~~

### config\sources.yaml

~~~~yaml
# ===========================================================================
# sources.yaml — Fuentes de noticias de tecnología / IA
# ---------------------------------------------------------------------------
# Para AGREGAR una fuente, copia un bloque y rellena los campos.
# Para QUITARLA, bórrala o pon "enabled: false".
#
# Campos por fuente:
#   name:          Nombre legible de la fuente.
#   enabled:       true/false para activarla o desactivarla.
#   trusted:       true si es una fuente confiable (suma puntos en el ranking).
#   region:        País / región principal (se usa como pista de procedencia).
#   listing_urls:  Páginas índice (portada de sección) de donde sacar enlaces.
#   rss:           (opcional) Feed RSS/Atom. Se prefiere RSS si existe: es más
#                  estable y respetuoso que raspar el HTML.
#   article_pattern: (opcional) substring que debe contener la URL de un
#                  artículo válido para esa fuente (filtra menús, tags, etc.).
#   needs_js:      true si la página necesita Playwright para renderizar.
#
# IMPORTANTE: Este programa NO salta paywalls, captchas ni autenticación, y
# respeta robots.txt. Si una fuente bloquea el scraping, simplemente se omite.
# ===========================================================================

sources:
  # -------------------- Agencias / medios globales --------------------------
  - name: "Reuters Technology"
    enabled: true
    trusted: true
    region: "Global"
    listing_urls:
      - "https://www.reuters.com/technology/"
    article_pattern: "/technology/"
    needs_js: true

  - name: "AP Technology"
    enabled: true
    trusted: true
    region: "Global / USA"
    listing_urls:
      - "https://apnews.com/hub/technology"
    article_pattern: "/article/"
    needs_js: false

  - name: "BBC Technology"
    enabled: true
    trusted: true
    region: "Global / UK"
    rss: "https://feeds.bbci.co.uk/news/technology/rss.xml"
    listing_urls:
      - "https://www.bbc.com/innovation"
    article_pattern: "/news/"
    needs_js: false

  - name: "TechCrunch"
    enabled: true
    trusted: true
    region: "Global / USA"
    rss: "https://techcrunch.com/feed/"
    listing_urls:
      - "https://techcrunch.com/"
    article_pattern: "techcrunch.com/20"
    needs_js: false

  - name: "The Verge"
    enabled: true
    trusted: true
    region: "Global / USA"
    rss: "https://www.theverge.com/rss/index.xml"
    listing_urls:
      - "https://www.theverge.com/tech"
    article_pattern: "/2"
    needs_js: false

  - name: "Wired"
    enabled: true
    trusted: true
    region: "Global / USA"
    rss: "https://www.wired.com/feed/category/business/artificial-intelligence/latest/rss"
    listing_urls:
      - "https://www.wired.com/tag/artificial-intelligence/"
    article_pattern: "/story/"
    needs_js: false

  - name: "MIT Technology Review"
    enabled: true
    trusted: true
    region: "Global / USA"
    rss: "https://www.technologyreview.com/feed/"
    listing_urls:
      - "https://www.technologyreview.com/topic/artificial-intelligence/"
    article_pattern: "/20"
    needs_js: false

  - name: "CNBC Technology"
    enabled: true
    trusted: true
    region: "Global / USA"
    rss: "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=19854910"
    listing_urls:
      - "https://www.cnbc.com/technology/"
    article_pattern: "/20"
    needs_js: false

  - name: "Euronews Next"
    enabled: true
    trusted: true
    region: "Europe / Global"
    rss: "https://www.euronews.com/next/rss"
    listing_urls:
      - "https://www.euronews.com/next"
    article_pattern: "/next/"
    needs_js: false

  - name: "DW Technology"
    enabled: true
    trusted: true
    region: "Germany / Global"
    rss: "https://rss.dw.com/rdf/rss-en-sci"
    listing_urls:
      - "https://www.dw.com/en/science/s-12526"
    article_pattern: "/a-"
    needs_js: false

  - name: "France24 Technology"
    enabled: true
    trusted: true
    region: "France / Global"
    rss: "https://www.france24.com/en/tag/technology/rss"
    listing_urls:
      - "https://www.france24.com/en/tag/technology/"
    article_pattern: "/en/"
    needs_js: false

  # -------------------- Medios tech en español ------------------------------
  - name: "Xataka"
    enabled: true
    trusted: true
    region: "España / LatAm"
    rss: "https://www.xataka.com/tag/inteligencia-artificial/rss"
    listing_urls:
      - "https://www.xataka.com/categoria/inteligencia-artificial"
    article_pattern: "xataka.com/"
    needs_js: false

  - name: "Genbeta"
    enabled: true
    trusted: true
    region: "España"
    rss: "https://www.genbeta.com/tag/inteligencia-artificial/rss"
    listing_urls:
      - "https://www.genbeta.com/categoria/inteligencia-artificial"
    article_pattern: "genbeta.com/"
    needs_js: false

  - name: "Hipertextual"
    enabled: true
    trusted: true
    region: "España / LatAm"
    rss: "https://hipertextual.com/feed"
    listing_urls:
      - "https://hipertextual.com/tag/inteligencia-artificial"
    article_pattern: "hipertextual.com/20"
    needs_js: false

  # -------------------- Plantilla para tus propias fuentes ------------------
  # - name: "Mi Fuente Tech"
  #   enabled: false
  #   trusted: false
  #   region: "Global"
  #   rss: "https://ejemplo.com/feed"
  #   listing_urls:
  #     - "https://ejemplo.com/tecnologia"
  #   article_pattern: "/articulo/"
  #   needs_js: false

~~~~

### exportar-proyecto.backup.ps1

~~~~powershell
```powershell
param(
    [string]$ProjectPath = (Get-Location).Path,
    [switch]$IncludeData,
    [switch]$IncludeOutput
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ============================================================
# CONFIGURACIÓN
# ============================================================

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$projectRoot = (Resolve-Path $ProjectPath).Path.TrimEnd("\", "/")
$projectName = Split-Path $projectRoot -Leaf

$exportBase = Join-Path $projectRoot "_export"
$exportName = "${projectName}_${timestamp}"
$stagingPath = Join-Path $exportBase $exportName
$zipPath = Join-Path $exportBase "${exportName}.zip"

$maxTextFileSize = 2MB

# Carpetas excluidas por defecto.
$excludedDirectories = @(
    ".git",
    ".venv",
    "venv",
    "env",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".idea",
    ".vscode",
    "node_modules",
    "dist",
    "build",
    "_export"
)

if (-not $IncludeData) {
    $excludedDirectories += "data"
}

if (-not $IncludeOutput) {
    $excludedDirectories += "output"
}

# Nunca exportar secretos.
$excludedExactFiles = @(
    ".env"
)

# Archivos potencialmente sensibles o innecesarios.
$excludedExtensions = @(
    ".db-journal",
    ".sqlite-journal",
    ".pyc",
    ".pyo",
    ".log",
    ".tmp",
    ".temp"
)

# Extensiones que se incluirán dentro de PROJECT_CONTEXT.md.
$textExtensions = @(
    ".py",
    ".html",
    ".htm",
    ".css",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".json",
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".cfg",
    ".conf",
    ".md",
    ".txt",
    ".ps1",
    ".psm1",
    ".sh",
    ".bat",
    ".cmd",
    ".xml",
    ".sql",
    ".csv",
    ".env.example"
)

# ============================================================
# FUNCIONES
# ============================================================

function Get-RelativePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$FullPath
    )

    return $FullPath.Substring($projectRoot.Length).TrimStart("\", "/")
}

function Test-ExcludedPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath,

        [Parameter(Mandatory = $true)]
        [System.IO.FileInfo]$File
    )

    $segments = $RelativePath -split "[\\/]"

    foreach ($segment in $segments) {
        if ($excludedDirectories -contains $segment) {
            return $true
        }
    }

    if ($excludedExactFiles -contains $File.Name) {
        return $true
    }

    if ($excludedExtensions -contains $File.Extension.ToLowerInvariant()) {
        return $true
    }

    return $false
}

function Test-TextFile {
    param(
        [Parameter(Mandatory = $true)]
        [System.IO.FileInfo]$File
    )

    if ($File.Name -eq ".gitignore") {
        return $true
    }

    if ($File.Name -eq ".env.example") {
        return $true
    }

    if ($File.Name -eq "requirements.txt") {
        return $true
    }

    return $textExtensions -contains $File.Extension.ToLowerInvariant()
}

function Get-LanguageName {
    param(
        [Parameter(Mandatory = $true)]
        [System.IO.FileInfo]$File
    )

    switch ($File.Extension.ToLowerInvariant()) {
        ".py"   { return "python" }
        ".html" { return "html" }
        ".htm"  { return "html" }
        ".css"  { return "css" }
        ".js"   { return "javascript" }
        ".jsx"  { return "jsx" }
        ".ts"   { return "typescript" }
        ".tsx"  { return "tsx" }
        ".json" { return "json" }
        ".yaml" { return "yaml" }
        ".yml"  { return "yaml" }
        ".toml" { return "toml" }
        ".xml"  { return "xml" }
        ".sql"  { return "sql" }
        ".ps1"  { return "powershell" }
        ".sh"   { return "bash" }
        ".bat"  { return "batch" }
        ".cmd"  { return "batch" }
        ".md"   { return "markdown" }
        default { return "text" }
    }
}

# ============================================================
# PREPARAR CARPETAS
# ============================================================

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host " EXPORTADOR DE PROYECTO" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "Proyecto: $projectRoot"
Write-Host ""

New-Item -ItemType Directory -Force -Path $exportBase | Out-Null
New-Item -ItemType Directory -Force -Path $stagingPath | Out-Null

if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

# ============================================================
# BUSCAR Y COPIAR ARCHIVOS
# ============================================================

$sourceFiles = Get-ChildItem `
    -Path $projectRoot `
    -File `
    -Recurse `
    -Force |
    ForEach-Object {
        $relativePath = Get-RelativePath -FullPath $_.FullName

        if (-not (Test-ExcludedPath -RelativePath $relativePath -File $_)) {
            [PSCustomObject]@{
                File         = $_
                RelativePath = $relativePath
            }
        }
    } |
    Sort-Object RelativePath

if (-not $sourceFiles) {
    throw "No se encontraron archivos para exportar."
}

foreach ($item in $sourceFiles) {
    $destination = Join-Path $stagingPath $item.RelativePath
    $destinationDirectory = Split-Path $destination -Parent

    if (-not (Test-Path $destinationDirectory)) {
        New-Item `
            -ItemType Directory `
            -Force `
            -Path $destinationDirectory | Out-Null
    }

    Copy-Item `
        -LiteralPath $item.File.FullName `
        -Destination $destination `
        -Force
}

Write-Host "[OK] Archivos copiados: $($sourceFiles.Count)" -ForegroundColor Green

# ============================================================
# GENERAR ESTRUCTURA DEL PROYECTO
# ============================================================

$treePath = Join-Path $stagingPath "PROJECT_TREE.txt"

$treeContent = @()
$treeContent += "PROYECTO: $projectName"
$treeContent += "GENERADO: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
$treeContent += ""
$treeContent += "ARCHIVOS:"
$treeContent += ""

foreach ($item in $sourceFiles) {
    $treeContent += $item.RelativePath
}

$treeContent | Set-Content `
    -Path $treePath `
    -Encoding UTF8

# ============================================================
# GENERAR MANIFIESTO JSON
# ============================================================

$manifestPath = Join-Path $stagingPath "PROJECT_MANIFEST.json"

$manifestItems = foreach ($item in $sourceFiles) {
    $hash = Get-FileHash `
        -LiteralPath $item.File.FullName `
        -Algorithm SHA256

    [PSCustomObject]@{
        path          = $item.RelativePath
        size_bytes    = $item.File.Length
        extension     = $item.File.Extension
        sha256        = $hash.Hash
        last_modified = $item.File.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
    }
}

$manifest = [PSCustomObject]@{
    project_name      = $projectName
    generated_at      = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    total_files       = $sourceFiles.Count
    includes_data     = [bool]$IncludeData
    includes_output   = [bool]$IncludeOutput
    secrets_excluded  = @(".env")
    files             = $manifestItems
}

$manifest |
    ConvertTo-Json -Depth 10 |
    Set-Content -Path $manifestPath -Encoding UTF8

# ============================================================
# GENERAR CONTEXTO COMPLETO PARA CHATGPT / CODEX
# ============================================================

$contextPath = Join-Path $stagingPath "PROJECT_CONTEXT.md"
$builder = New-Object System.Text.StringBuilder

[void]$builder.AppendLine("# Contexto completo del proyecto")
[void]$builder.AppendLine("")
[void]$builder.AppendLine("- Proyecto: $projectName")
[void]$builder.AppendLine("- Generado: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
[void]$builder.AppendLine("- Total de archivos: $($sourceFiles.Count)")
[void]$builder.AppendLine("- .env fue excluido para proteger secretos.")
[void]$builder.AppendLine("")
[void]$builder.AppendLine("## Estructura")
[void]$builder.AppendLine("")
[void]$builder.AppendLine("~~~~text")

foreach ($item in $sourceFiles) {
    [void]$builder.AppendLine($item.RelativePath)
}

[void]$builder.AppendLine("~~~~")
[void]$builder.AppendLine("")
[void]$builder.AppendLine("## Contenido de los archivos")
[void]$builder.AppendLine("")

foreach ($item in $sourceFiles) {
    $file = $item.File

    if (-not (Test-TextFile -File $file)) {
        [void]$builder.AppendLine("### $($item.RelativePath)")
        [void]$builder.AppendLine("")
        [void]$builder.AppendLine(
            "_Archivo binario incluido en el ZIP. Tamaño: $($file.Length) bytes._"
        )
        [void]$builder.AppendLine("")
        continue
    }

    if ($file.Length -gt $maxTextFileSize) {
        [void]$builder.AppendLine("### $($item.RelativePath)")
        [void]$builder.AppendLine("")
        [void]$builder.AppendLine(
            "_Archivo omitido del contexto por superar $maxTextFileSize bytes. Está incluido en el ZIP._"
        )
        [void]$builder.AppendLine("")
        continue
    }

    try {
        $language = Get-LanguageName -File $file
        $content = Get-Content `
            -LiteralPath $file.FullName `
            -Raw `
            -Encoding UTF8

        [void]$builder.AppendLine("### $($item.RelativePath)")
        [void]$builder.AppendLine("")
        [void]$builder.AppendLine("~~~~$language")
        [void]$builder.AppendLine($content)
        [void]$builder.AppendLine("~~~~")
        [void]$builder.AppendLine("")
    }
    catch {
        [void]$builder.AppendLine("### $($item.RelativePath)")
        [void]$builder.AppendLine("")
        [void]$builder.AppendLine(
            "_No se pudo leer como texto: $($_.Exception.Message)_"
        )
        [void]$builder.AppendLine("")
    }
}

$builder.ToString() |
    Set-Content -Path $contextPath -Encoding UTF8

Write-Host "[OK] PROJECT_CONTEXT.md generado" -ForegroundColor Green

# ============================================================
# GENERAR PROMPT BASE PARA CODEX
# ============================================================

$codexPromptPath = Join-Path $stagingPath "CODEX_REVIEW_PROMPT.md"

$codexPrompt = @'
# Revisión del proyecto Tech News Video Scraper

Analiza completamente este proyecto antes de modificar archivos.

## Contexto

Es una aplicación local en Python que:

- busca noticias de tecnología e inteligencia artificial;
- filtra noticias fuera del tema;
- evita noticias repetidas mediante SQLite;
- detecta imágenes y videos;
- traduce información al español;
- genera cinco slides visuales;
- agrega una imagen de introducción;
- agrega una imagen de salida;
- envía los slides a Telegram;
- guarda cada ejecución en una carpeta separada.

## Reglas de trabajo

1. No elimines funcionalidades que ya están operativas.
2. No cambies el diseño visual de los slides sin autorización.
3. No expongas ni escribas tokens de Telegram.
4. Usa las variables de `.env`.
5. No incluyas `.env` en commits.
6. Revisa el código completo antes de proponer cambios.
7. Identifica duplicación, errores silenciosos y dependencias innecesarias.
8. Mantén compatibilidad con Windows y PowerShell.
9. Ejecuta pruebas o validaciones antes de dar una tarea por terminada.
10. Explica qué archivos cambiarás antes de modificarlos.

## Primera tarea

Realiza primero una auditoría y entrega:

- resumen de la arquitectura actual;
- flujo completo desde la búsqueda hasta Telegram;
- errores o riesgos encontrados;
- mejoras prioritarias;
- archivos que deberían modificarse;
- propuesta de implementación por etapas.

No modifiques todavía el código hasta finalizar esta auditoría.
'@

$codexPrompt |
    Set-Content -Path $codexPromptPath -Encoding UTF8

# ============================================================
# GENERAR RESUMEN
# ============================================================

$summaryPath = Join-Path $stagingPath "EXPORT_SUMMARY.txt"

$textFileCount = (
    $sourceFiles |
    Where-Object { Test-TextFile -File $_.File }
).Count

$binaryFileCount = $sourceFiles.Count - $textFileCount

$summary = @"
EXPORTACIÓN COMPLETADA

Proyecto: $projectName
Fecha: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")

Archivos originales exportados: $($sourceFiles.Count)
Archivos de texto: $textFileCount
Archivos binarios: $binaryFileCount

Incluye data: $([bool]$IncludeData)
Incluye output: $([bool]$IncludeOutput)

Archivos adicionales generados:
- PROJECT_TREE.txt
- PROJECT_MANIFEST.json
- PROJECT_CONTEXT.md
- CODEX_REVIEW_PROMPT.md
- EXPORT_SUMMARY.txt

Por seguridad no se incluyó:
- .env
- .venv
- cachés de Python
- repositorio .git
"@

$summary |
    Set-Content -Path $summaryPath -Encoding UTF8

# ============================================================
# CREAR ZIP
# ============================================================

Compress-Archive `
    -Path (Join-Path $stagingPath "*") `
    -DestinationPath $zipPath `
    -CompressionLevel Optimal `
    -Force

$zipSizeMb = [math]::Round(
    (Get-Item $zipPath).Length / 1MB,
    2
)

Write-Host ""
Write-Host "=============================================" -ForegroundColor Green
Write-Host " EXPORTACIÓN COMPLETADA" -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Carpeta preparada:"
Write-Host $stagingPath -ForegroundColor Yellow
Write-Host ""
Write-Host "ZIP para subir a ChatGPT o revisar:"
Write-Host $zipPath -ForegroundColor Yellow
Write-Host ""
Write-Host "Tamaño ZIP: $zipSizeMb MB"
Write-Host ""
Write-Host "IMPORTANTE: el archivo .env no fue incluido." -ForegroundColor Cyan
```

~~~~

### exportar-proyecto.ps1

~~~~powershell
param(
    [string]$ProjectPath = (Get-Location).Path,
    [switch]$IncludeData,
    [switch]$IncludeOutput
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ============================================================
# CONFIGURACIÃ“N
# ============================================================

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$projectRoot = (Resolve-Path $ProjectPath).Path.TrimEnd("\", "/")
$projectName = Split-Path $projectRoot -Leaf

$exportBase = Join-Path $projectRoot "_export"
$exportName = "${projectName}_${timestamp}"
$stagingPath = Join-Path $exportBase $exportName
$zipPath = Join-Path $exportBase "${exportName}.zip"

$maxTextFileSize = 2MB

# Carpetas excluidas por defecto.
$excludedDirectories = @(
    ".git",
    ".venv",
    "venv",
    "env",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".idea",
    ".vscode",
    "node_modules",
    "dist",
    "build",
    "_export"
)

if (-not $IncludeData) {
    $excludedDirectories += "data"
}

if (-not $IncludeOutput) {
    $excludedDirectories += "output"
}

# Nunca exportar secretos.
$excludedExactFiles = @(
    ".env"
)

# Archivos potencialmente sensibles o innecesarios.
$excludedExtensions = @(
    ".db-journal",
    ".sqlite-journal",
    ".pyc",
    ".pyo",
    ".log",
    ".tmp",
    ".temp"
)

# Extensiones que se incluirÃ¡n dentro de PROJECT_CONTEXT.md.
$textExtensions = @(
    ".py",
    ".html",
    ".htm",
    ".css",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".json",
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".cfg",
    ".conf",
    ".md",
    ".txt",
    ".ps1",
    ".psm1",
    ".sh",
    ".bat",
    ".cmd",
    ".xml",
    ".sql",
    ".csv",
    ".env.example"
)

# ============================================================
# FUNCIONES
# ============================================================

function Get-RelativePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$FullPath
    )

    return $FullPath.Substring($projectRoot.Length).TrimStart("\", "/")
}

function Test-ExcludedPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath,

        [Parameter(Mandatory = $true)]
        [System.IO.FileInfo]$File
    )

    $segments = $RelativePath -split "[\\/]"

    foreach ($segment in $segments) {
        if ($excludedDirectories -contains $segment) {
            return $true
        }
    }

    if ($excludedExactFiles -contains $File.Name) {
        return $true
    }

    if ($excludedExtensions -contains $File.Extension.ToLowerInvariant()) {
        return $true
    }

    return $false
}

function Test-TextFile {
    param(
        [Parameter(Mandatory = $true)]
        [System.IO.FileInfo]$File
    )

    if ($File.Name -eq ".gitignore") {
        return $true
    }

    if ($File.Name -eq ".env.example") {
        return $true
    }

    if ($File.Name -eq "requirements.txt") {
        return $true
    }

    return $textExtensions -contains $File.Extension.ToLowerInvariant()
}

function Get-LanguageName {
    param(
        [Parameter(Mandatory = $true)]
        [System.IO.FileInfo]$File
    )

    switch ($File.Extension.ToLowerInvariant()) {
        ".py"   { return "python" }
        ".html" { return "html" }
        ".htm"  { return "html" }
        ".css"  { return "css" }
        ".js"   { return "javascript" }
        ".jsx"  { return "jsx" }
        ".ts"   { return "typescript" }
        ".tsx"  { return "tsx" }
        ".json" { return "json" }
        ".yaml" { return "yaml" }
        ".yml"  { return "yaml" }
        ".toml" { return "toml" }
        ".xml"  { return "xml" }
        ".sql"  { return "sql" }
        ".ps1"  { return "powershell" }
        ".sh"   { return "bash" }
        ".bat"  { return "batch" }
        ".cmd"  { return "batch" }
        ".md"   { return "markdown" }
        default { return "text" }
    }
}

# ============================================================
# PREPARAR CARPETAS
# ============================================================

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host " EXPORTADOR DE PROYECTO" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "Proyecto: $projectRoot"
Write-Host ""

New-Item -ItemType Directory -Force -Path $exportBase | Out-Null
New-Item -ItemType Directory -Force -Path $stagingPath | Out-Null

if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

# ============================================================
# BUSCAR Y COPIAR ARCHIVOS
# ============================================================

$sourceFiles = Get-ChildItem `
    -Path $projectRoot `
    -File `
    -Recurse `
    -Force |
    ForEach-Object {
        $relativePath = Get-RelativePath -FullPath $_.FullName

        if (-not (Test-ExcludedPath -RelativePath $relativePath -File $_)) {
            [PSCustomObject]@{
                File         = $_
                RelativePath = $relativePath
            }
        }
    } |
    Sort-Object RelativePath

if (-not $sourceFiles) {
    throw "No se encontraron archivos para exportar."
}

foreach ($item in $sourceFiles) {
    $destination = Join-Path $stagingPath $item.RelativePath
    $destinationDirectory = Split-Path $destination -Parent

    if (-not (Test-Path $destinationDirectory)) {
        New-Item `
            -ItemType Directory `
            -Force `
            -Path $destinationDirectory | Out-Null
    }

    Copy-Item `
        -LiteralPath $item.File.FullName `
        -Destination $destination `
        -Force
}

Write-Host "[OK] Archivos copiados: $($sourceFiles.Count)" -ForegroundColor Green

# ============================================================
# GENERAR ESTRUCTURA DEL PROYECTO
# ============================================================

$treePath = Join-Path $stagingPath "PROJECT_TREE.txt"

$treeContent = @()
$treeContent += "PROYECTO: $projectName"
$treeContent += "GENERADO: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
$treeContent += ""
$treeContent += "ARCHIVOS:"
$treeContent += ""

foreach ($item in $sourceFiles) {
    $treeContent += $item.RelativePath
}

$treeContent | Set-Content `
    -Path $treePath `
    -Encoding UTF8

# ============================================================
# GENERAR MANIFIESTO JSON
# ============================================================

$manifestPath = Join-Path $stagingPath "PROJECT_MANIFEST.json"

$manifestItems = foreach ($item in $sourceFiles) {
    $hash = Get-FileHash `
        -LiteralPath $item.File.FullName `
        -Algorithm SHA256

    [PSCustomObject]@{
        path          = $item.RelativePath
        size_bytes    = $item.File.Length
        extension     = $item.File.Extension
        sha256        = $hash.Hash
        last_modified = $item.File.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
    }
}

$manifest = [PSCustomObject]@{
    project_name      = $projectName
    generated_at      = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    total_files       = $sourceFiles.Count
    includes_data     = [bool]$IncludeData
    includes_output   = [bool]$IncludeOutput
    secrets_excluded  = @(".env")
    files             = $manifestItems
}

$manifest |
    ConvertTo-Json -Depth 10 |
    Set-Content -Path $manifestPath -Encoding UTF8

# ============================================================
# GENERAR CONTEXTO COMPLETO PARA CHATGPT / CODEX
# ============================================================

$contextPath = Join-Path $stagingPath "PROJECT_CONTEXT.md"
$builder = New-Object System.Text.StringBuilder

[void]$builder.AppendLine("# Contexto completo del proyecto")
[void]$builder.AppendLine("")
[void]$builder.AppendLine("- Proyecto: $projectName")
[void]$builder.AppendLine("- Generado: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
[void]$builder.AppendLine("- Total de archivos: $($sourceFiles.Count)")
[void]$builder.AppendLine("- .env fue excluido para proteger secretos.")
[void]$builder.AppendLine("")
[void]$builder.AppendLine("## Estructura")
[void]$builder.AppendLine("")
[void]$builder.AppendLine("~~~~text")

foreach ($item in $sourceFiles) {
    [void]$builder.AppendLine($item.RelativePath)
}

[void]$builder.AppendLine("~~~~")
[void]$builder.AppendLine("")
[void]$builder.AppendLine("## Contenido de los archivos")
[void]$builder.AppendLine("")

foreach ($item in $sourceFiles) {
    $file = $item.File

    if (-not (Test-TextFile -File $file)) {
        [void]$builder.AppendLine("### $($item.RelativePath)")
        [void]$builder.AppendLine("")
        [void]$builder.AppendLine(
            "_Archivo binario incluido en el ZIP. TamaÃ±o: $($file.Length) bytes._"
        )
        [void]$builder.AppendLine("")
        continue
    }

    if ($file.Length -gt $maxTextFileSize) {
        [void]$builder.AppendLine("### $($item.RelativePath)")
        [void]$builder.AppendLine("")
        [void]$builder.AppendLine(
            "_Archivo omitido del contexto por superar $maxTextFileSize bytes. EstÃ¡ incluido en el ZIP._"
        )
        [void]$builder.AppendLine("")
        continue
    }

    try {
        $language = Get-LanguageName -File $file
        $content = Get-Content `
            -LiteralPath $file.FullName `
            -Raw `
            -Encoding UTF8

        [void]$builder.AppendLine("### $($item.RelativePath)")
        [void]$builder.AppendLine("")
        [void]$builder.AppendLine("~~~~$language")
        [void]$builder.AppendLine($content)
        [void]$builder.AppendLine("~~~~")
        [void]$builder.AppendLine("")
    }
    catch {
        [void]$builder.AppendLine("### $($item.RelativePath)")
        [void]$builder.AppendLine("")
        [void]$builder.AppendLine(
            "_No se pudo leer como texto: $($_.Exception.Message)_"
        )
        [void]$builder.AppendLine("")
    }
}

$builder.ToString() |
    Set-Content -Path $contextPath -Encoding UTF8

Write-Host "[OK] PROJECT_CONTEXT.md generado" -ForegroundColor Green

# ============================================================
# GENERAR PROMPT BASE PARA CODEX
# ============================================================

$codexPromptPath = Join-Path $stagingPath "CODEX_REVIEW_PROMPT.md"

$codexPrompt = @'
# RevisiÃ³n del proyecto Tech News Video Scraper

Analiza completamente este proyecto antes de modificar archivos.

## Contexto

Es una aplicaciÃ³n local en Python que:

- busca noticias de tecnologÃ­a e inteligencia artificial;
- filtra noticias fuera del tema;
- evita noticias repetidas mediante SQLite;
- detecta imÃ¡genes y videos;
- traduce informaciÃ³n al espaÃ±ol;
- genera cinco slides visuales;
- agrega una imagen de introducciÃ³n;
- agrega una imagen de salida;
- envÃ­a los slides a Telegram;
- guarda cada ejecuciÃ³n en una carpeta separada.

## Reglas de trabajo

1. No elimines funcionalidades que ya estÃ¡n operativas.
2. No cambies el diseÃ±o visual de los slides sin autorizaciÃ³n.
3. No expongas ni escribas tokens de Telegram.
4. Usa las variables de `.env`.
5. No incluyas `.env` en commits.
6. Revisa el cÃ³digo completo antes de proponer cambios.
7. Identifica duplicaciÃ³n, errores silenciosos y dependencias innecesarias.
8. MantÃ©n compatibilidad con Windows y PowerShell.
9. Ejecuta pruebas o validaciones antes de dar una tarea por terminada.
10. Explica quÃ© archivos cambiarÃ¡s antes de modificarlos.

## Primera tarea

Realiza primero una auditorÃ­a y entrega:

- resumen de la arquitectura actual;
- flujo completo desde la bÃºsqueda hasta Telegram;
- errores o riesgos encontrados;
- mejoras prioritarias;
- archivos que deberÃ­an modificarse;
- propuesta de implementaciÃ³n por etapas.

No modifiques todavÃ­a el cÃ³digo hasta finalizar esta auditorÃ­a.
'@

$codexPrompt |
    Set-Content -Path $codexPromptPath -Encoding UTF8

# ============================================================
# GENERAR RESUMEN
# ============================================================

$summaryPath = Join-Path $stagingPath "EXPORT_SUMMARY.txt"

$textFileCount = (
    $sourceFiles |
    Where-Object { Test-TextFile -File $_.File }
).Count

$binaryFileCount = $sourceFiles.Count - $textFileCount

$summary = @"
EXPORTACIÃ“N COMPLETADA

Proyecto: $projectName
Fecha: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")

Archivos originales exportados: $($sourceFiles.Count)
Archivos de texto: $textFileCount
Archivos binarios: $binaryFileCount

Incluye data: $([bool]$IncludeData)
Incluye output: $([bool]$IncludeOutput)

Archivos adicionales generados:
- PROJECT_TREE.txt
- PROJECT_MANIFEST.json
- PROJECT_CONTEXT.md
- CODEX_REVIEW_PROMPT.md
- EXPORT_SUMMARY.txt

Por seguridad no se incluyÃ³:
- .env
- .venv
- cachÃ©s de Python
- repositorio .git
"@

$summary |
    Set-Content -Path $summaryPath -Encoding UTF8

# ============================================================
# CREAR ZIP
# ============================================================

Compress-Archive `
    -Path (Join-Path $stagingPath "*") `
    -DestinationPath $zipPath `
    -CompressionLevel Optimal `
    -Force

$zipSizeMb = [math]::Round(
    (Get-Item $zipPath).Length / 1MB,
    2
)

Write-Host ""
Write-Host "=============================================" -ForegroundColor Green
Write-Host " EXPORTACIÃ“N COMPLETADA" -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Carpeta preparada:"
Write-Host $stagingPath -ForegroundColor Yellow
Write-Host ""
Write-Host "ZIP para subir a ChatGPT o revisar:"
Write-Host $zipPath -ForegroundColor Yellow
Write-Host ""
Write-Host "TamaÃ±o ZIP: $zipSizeMb MB"
Write-Host ""
Write-Host "IMPORTANTE: el archivo .env no fue incluido." -ForegroundColor Cyan

~~~~

### README.md

~~~~markdown
# Tech News Video Scraper + generador de carruseles

Aplicación local en Python que busca noticias **recientes** sobre **tecnología,
inteligencia artificial, robótica, ciencia aplicada, chips, software y empresas
tecnológicas**, las puntúa, las guarda en **SQLite** y genera por cada noticia
una **pieza visual final `slide.png` (1080×1350)** lista para publicar como
**carrusel de Instagram** estilo tecnológico/premium, además de una galería
`index.html` para revisarlas todas.

> Pensada como **MVP local para Windows**, con arquitectura modular para luego
> integrarse con una **API FastAPI** o una **app Flutter**.

---

## Características

- Pregunta el **tema** al iniciar (ENTER = *tecnología e inteligencia artificial*).
- Configurable: número de noticias (por defecto **5**) e idioma de salida (por defecto **español**).
- Busca en **múltiples fuentes globales** definidas en `config/sources.yaml` (RSS o HTML).
- **Genera `slide.png` real por noticia** (1080×1350) — *no se queda en `card.html` sin renderizar*.
- **Prioriza noticias con video**; si no completa las N pedidas, **rellena con
  noticias de imagen de alta calidad** (`media_type: image`).
- Detecta video por: `<video>`, iframes (YouTube/Vimeo/Dailymotion…), Open Graph, JSON-LD y embeds.
- **Comprueba si el video es embebible** (cabeceras `X-Frame-Options`/`CSP`). Si
  está bloqueado (caso B), **no falla**: guarda el enlace + `video_poster.jpg` y
  usa esa imagen en el slide, marcando `embed_status: blocked` y el motivo.
- **Filtro temático DURO (Tech/IA)** antes del ranking y de guardar/exportar:
  si no es tecnología/IA, **no entra**. Rechaza política general, economía,
  deportes, crimen, farándula, etc. (acepta política/regulación **solo** si está
  ligada a IA/tecnología, p. ej. regulación de IA o ley de chips).
- **Traducción** modular al español (título, descripción, titular y caption cortos para el slide).
- **Ranking** con puntuación para elegir las mejores noticias (con *gate*: nada
  que no pase el filtro llega al top 5).
- **Deduplicación** por `canonical_url`, `article_url` y hash de título.
- Galería `index.html` + `summary.json` + `summary.txt` por ejecución.
- **Envío automático a Telegram** de los 5 slides al finalizar (opcional, por `.env`).
- Respeta `robots.txt`. **No** salta paywalls, captchas, logins ni DRM. Guarda
  enlaces/embeds de video de terceros (no descarga videos protegidos).

## Filtro temático (Tech/IA)

Implementado en `src/topic_filter.py` y configurable en `config/settings.yaml`
bajo `topic_filter` (`enabled`, `min_topic_score`, `positive_keywords`,
`negative_keywords`). Por cada noticia loguea la decisión:
`[ACEPTADA TECH/IA]`, `[RECHAZADA NO TECH]` o `[RECHAZADA POLÍTICA]`. Las
rechazadas no se guardan en SQLite ni generan slide.

## Envío a Telegram

1. Copia `.env.example` a `.env` y rellena tus datos:

   ```env
   TELEGRAM_ENABLED=true
   TELEGRAM_BOT_TOKEN=tu_token_de_BotFather
   TELEGRAM_CHAT_ID=tu_chat_id
   TELEGRAM_SEND_AS_ALBUM=true
   ```

2. Al finalizar, el programa envía los `slide.png` generados. Si
   `TELEGRAM_SEND_AS_ALBUM=true` usa `sendMediaGroup` (álbum); si falla, envía
   uno por uno con `sendPhoto`. Cada slide lleva un caption con número, título,
   fuente y enlace al artículo.

   - Si faltan variables: `[TELEGRAM] No configurado. Se omite envío.`
   - Si está desactivado: `[TELEGRAM] Desactivado por TELEGRAM_ENABLED=false`
   - Si todo va bien: `[TELEGRAM] Slides enviados correctamente.`

   El archivo `.env` **no** se sube al repositorio (está en `.gitignore`).

## Cómo se genera el `slide.png`

1. **Opción preferida (más elegante):** `card_template.html` (Jinja2 + CSS) se
   abre con **Playwright** y se captura un screenshot exacto a 1080×1350. Incluye
   imagen de fondo, degradado oscuro, titular en MAYÚSCULAS con **palabras clave
   en violeta** y footer con fuente + fecha.
2. **Fallback automático (sin navegador):** si Playwright no está instalado, se
   dibuja el slide con **Pillow** (gradiente tecnológico + imagen + texto). Así
   el sistema **nunca** se queda sin `slide.png`.

> Para el resultado visual completo (palabras clave en violeta, imagen de fondo
> nítida) ejecuta `playwright install` una vez. Sin él, el fallback Pillow sigue
> produciendo un slide limpio y usable.

---

## Requisitos

- Python 3.10+ (probado con 3.10).
- Windows (las instrucciones usan PowerShell), aunque funciona en macOS/Linux.

---

## Instalación (Windows PowerShell)

```powershell
cd C:\ProyectosIA\tech-news-video-scraper
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
playwright install
python app.py
```

> `playwright install` solo es necesario si quieres renderizado dinámico para
> páginas que cargan el video por JavaScript. Si no lo instalas, el programa
> seguirá funcionando con `requests` + `BeautifulSoup` y RSS.

### Uso

```powershell
# Interactivo (pregunta tema, número e idioma)
python app.py

# Directo, sin preguntar
python app.py --topic "robótica e inteligencia artificial" --num 5 --lang es --no-input
```

Argumentos:

| Flag         | Descripción                              | Por defecto |
|--------------|------------------------------------------|-------------|
| `--topic`    | Tema de búsqueda                         | tecnología e IA |
| `--num`      | Número de noticias a generar             | 5           |
| `--lang`     | Idioma de salida                         | es          |
| `--no-input` | No preguntar; usar valores por defecto   | —           |

---

## Estructura del proyecto

```
tech_news_video_scraper/
├── app.py                 # Orquestador CLI
├── requirements.txt
├── README.md
├── config/
│   ├── sources.yaml       # Fuentes (agregar/quitar aquí)
│   └── settings.yaml      # Configuración general
├── data/
│   └── news.db            # Base SQLite (se crea sola)
├── output/                # Carpetas de salida por ejecución
├── templates/
│   ├── card_template.html   # Slide 1080x1350 (Jinja2 + CSS) → screenshot
│   ├── embed_template.html  # Reproductor / fallback a poster
│   ├── index_template.html  # Galería del run
│   └── card.html            # (plantilla heredada, opcional)
└── src/
    ├── __init__.py
    ├── database.py        # Esquema SQLite + deduplicación + migración
    ├── models.py          # Dataclasses (Article, Source, Run)
    ├── scraper.py         # Descarga listados/artículos (requests + Playwright)
    ├── source_loader.py   # Carga sources.yaml
    ├── video_detector.py  # Detección de video
    ├── media_extractor.py # Hero image, poster, chequeo de embed, descargas
    ├── card_renderer.py   # Render del slide.png (Playwright + fallback Pillow)
    ├── topic_filter.py    # Filtro DURO Tech/IA (antes de guardar/exportar)
    ├── telegram_sender.py # Envío de los slides a Telegram (.env)
    ├── translator.py      # Traducción modular
    ├── ranker.py          # Puntuación / selección (con gate del filtro)
    ├── exporter.py        # Genera carpetas, slides, index/summary
    └── utils.py           # Hash, fechas, logging, URLs
```

---

## Salida generada

Por cada ejecución se crea:

```
output/2026-06-17_14-30-05/
├── index.html           # Galería con las 5 noticias (preview de cada slide)
├── summary.json         # Resumen estructurado del run + estadísticas
├── summary.txt          # Resumen legible
├── noticia_01/
│   ├── slide.png        # ★ PIEZA VISUAL FINAL 1080x1350 (carrusel)
│   ├── card.html        # HTML usado para generar el slide
│   ├── embed.html       # Reproductor del video (o fallback a poster)
│   ├── video_poster.jpg # Miniatura/poster del video (si existe)
│   ├── hero_image.jpg   # Imagen principal del artículo (si existe)
│   ├── metadata.json    # Metadatos + puntuación + embed_status
│   ├── noticia.json     # Objeto completo de la noticia
│   ├── noticia.txt      # Resumen legible
│   ├── source.url       # Acceso directo a la noticia
│   ├── video.url        # Acceso directo al video
│   ├── video_url.txt    # Enlace directo del video (caso B, no embebible)
│   └── README.txt
├── noticia_02/
└── ...
```

### Comportamiento del video

- **Caso A — video embebible:** `embed.html` muestra el reproductor; se guarda
  `video_embed_url` y `video_type`; `embed_status: ok`.
- **Caso B — video bloqueado** (`X-Frame-Options`/`CSP`/DRM): **no falla**. Se
  guarda `video_url.txt` + `video_poster.jpg`, se usa el poster en `slide.png`,
  y en `metadata.json` queda `embed_status: blocked` con el motivo.
- **Caso C — sin video pero con imagen:** se permite si la noticia es de alta
  calidad (entra en las mejores); `media_type: image`, se usa `hero_image.jpg`
  en el slide.

El slide está diseñado a **1080×1350 (4:5 vertical)** para carrusel de Instagram.

---

## Cómo agregar nuevas fuentes

Edita `config/sources.yaml` y añade un bloque. Lo más estable es usar **RSS**:

```yaml
  - name: "Mi Fuente Tech"
    enabled: true
    trusted: false           # true suma puntos en el ranking
    region: "Global"
    rss: "https://ejemplo.com/feed"        # preferido si existe
    listing_urls:
      - "https://ejemplo.com/tecnologia"   # alternativa: portada de sección
    article_pattern: "/articulo/"          # filtra qué URLs son artículos
    needs_js: false                        # true si necesita Playwright
```

- Si la fuente tiene **RSS**, rellena `rss` (más respetuoso y fiable).
- Si no, usa `listing_urls` + `article_pattern` (substring que aparece en las
  URLs de artículos reales, para filtrar menús/etiquetas).
- `needs_js: true` solo si la página carga el contenido/video con JavaScript.
- Para **desactivar** una fuente sin borrarla: `enabled: false`.

Las fuentes con `trusted: true` se intentan **primero**.

---

## Configuración (settings.yaml)

Lo más relevante:

- `defaults.topic / num_news / language` — valores por defecto.
- `search.max_age_days` — descarta noticias más viejas (0 = sin límite).
- `search.respect_robots_txt` — respeta `robots.txt`.
- `video.require_video` — exige video en cada noticia.
- `translation.api` — rellena `provider` (`deepl`/`google`) y `api_key` para usar
  una API; si lo dejas vacío, se usa el fallback gratuito `deep-translator`.
- `ranking.weights` — pesos de la puntuación.

### Traducción

1. **Con API** (mejor calidad): instala el SDK correspondiente
   (`pip install deepl` o `google-cloud-translate`) y rellena `translation.api`.
2. **Sin API** (por defecto): usa `deep-translator` (Google gratuito). Si no
   está disponible, los textos se guardan en su idioma original sin romper el flujo.

---

## Esquema SQLite (resumen)

- **runs**: una fila por ejecución (tema, idioma, contadores, carpeta).
- **sources**: fuentes vistas (nombre, confiable, región).
- **articles**: una fila por noticia guardada, con todos los campos
  (`title_original`, `title_es`, `summary_es`, `language_original`, `video_url`,
  `video_embed_url`, `video_type`, `published_at`, `content_hash`, `status`,
  `output_folder`, …) e índices para deduplicación.

---

## Buenas prácticas y límites legales

- No se evaden paywalls, captchas, autenticación ni DRM.
- Se respeta `robots.txt` cuando es accesible.
- No se descargan videos de terceros: se guarda el **enlace/embed público**.
- Úsalo de forma responsable y revisa los términos de uso de cada fuente.

---

## Integración futura (FastAPI / Flutter)

La lógica está separada de la CLI: `Database`, `Scraper`, `Translator`,
`Ranker` y `Exporter` son clases reutilizables. Para exponer una API basta con
envolver `run()` en un endpoint FastAPI y devolver los objetos `Article`
(ya serializables con `to_dict()`).

~~~~

### requirements.txt

~~~~text
# --- HTTP y parsing ---
requests>=2.31.0
beautifulsoup4>=4.12.0
lxml>=5.0.0

# --- Renderizado dinámico (opcional, solo cuando una página lo necesita) ---
playwright>=1.44.0

# --- Configuración ---
pyyaml>=6.0.1

# --- Detección de idioma ---
langdetect>=1.0.9

# --- Fechas ---
python-dateutil>=2.9.0

# --- Plantillas HTML ---
jinja2>=3.1.0

# --- Consola bonita ---
rich>=13.7.0

# --- Traducción (fallback gratuito; opcional pero recomendado) ---
deep-translator>=1.11.4

# --- Generación del slide.png (fallback de render y procesado de imágenes) ---
pillow>=10.2.0

# --- Envío a Telegram + carga de .env ---
python-dotenv>=1.0.1

# Nota: sqlite3, hashlib y urllib.parse forman parte de la librería estándar de Python.

~~~~

### src\__init__.py

~~~~python
"""Tech News Video Scraper — paquete principal.

Módulos:
    database       Capa SQLite (esquema + acceso a datos + deduplicación).
    models         Dataclasses (Article, Source, Run).
    source_loader  Carga y valida config/sources.yaml.
    scraper        Descarga listados y artículos (requests/BS4 + Playwright opcional).
    video_detector Detecta video en el HTML de un artículo.
    translator     Traducción modular al español (API opcional + fallback).
    ranker         Sistema de puntuación para elegir las mejores noticias.
    exporter       Genera las carpetas de salida y archivos por noticia.
    utils          Utilidades: hashing, fechas, logging, normalización.
"""

__version__ = "1.0.0"

~~~~

### src\card_renderer.py

~~~~python
"""card_renderer.py — genera slide.png (1080x1350) por noticia.

Opción preferida (más elegante y flexible):
    Jinja2 (card_template.html) -> Playwright abre el HTML -> screenshot a PNG.

Fallback automático (si Playwright/navegador no está disponible):
    Pillow dibuja el slide (gradiente tecnológico + imagen opcional + texto).

Así el sistema NUNCA se queda sin slide.png aunque no haya navegador instalado.
"""
from __future__ import annotations

import base64
import html as html_lib
import mimetypes
import re
import textwrap
from pathlib import Path
from typing import Optional

from jinja2 import Environment, FileSystemLoader, select_autoescape

from .models import Article
from .utils import get_logger

log = get_logger()

SLIDE_W, SLIDE_H = 1080, 1350

# Palabras clave que se resaltan en violeta en el titular
_HL_KEYWORDS = [
    "inteligencia artificial", "artificial intelligence", "ia", "ai",
    "machine learning", "deep learning", "chatgpt", "openai", "anthropic",
    "claude", "gemini", "robot", "robótica", "robotica", "robotics", "chip",
    "chips", "gpu", "nvidia", "cuántica", "cuantica", "quantum", "modelo",
    "modelos", "algoritmo", "startup", "tecnología", "tecnologia", "ciencia",
]


def _data_uri_for_image(path: Optional[str]) -> Optional[str]:
    if not path:
        return None
    p = Path(path)
    if not p.exists():
        return None
    mime = mimetypes.guess_type(str(p))[0] or "image/jpeg"
    b64 = base64.b64encode(p.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{b64}"


def highlight_keywords(headline: str) -> str:
    """Escapa el titular y envuelve palabras clave en <span class='hl'>."""
    safe = html_lib.escape(headline or "")
    # Ordenar por longitud desc para no romper subcadenas
    for kw in sorted(_HL_KEYWORDS, key=len, reverse=True):
        pattern = re.compile(rf"(?<![\w])({re.escape(kw)})(?![\w])", re.IGNORECASE)
        safe = pattern.sub(r"<span class='hl'>\1</span>", safe, count=1)
    return safe


def _dynamic_headline_size(headline: str) -> int:
    n = len(headline or "")
    if n <= 40:
        return 84
    if n <= 70:
        return 74
    if n <= 100:
        return 64
    return 56


class CardRenderer:
    def __init__(self, settings: dict, templates_dir: str = "templates"):
        self.templates_dir = Path(templates_dir)
        self.env = Environment(
            loader=FileSystemLoader(str(self.templates_dir)),
            autoescape=select_autoescape(["html", "xml"]),
        )
        pw = (settings or {}).get("playwright", {})
        self.pw_enabled = pw.get("enabled", True)
        self.pw_headless = pw.get("headless", True)
        self._browser = None
        self._pw_ctx = None
        self._pw_failed = False

    # ------------------------------------------------------------------ #
    def build_card_html(self, article: Article, image_path: Optional[str]) -> str:
        data_uri = _data_uri_for_image(image_path)
        headline = (article.short_headline_es or article.title_es
                    or article.title_original)
        caption = (article.short_caption_es or article.summary_es
                   or article.summary_original or "")
        if len(caption) > 240:
            caption = caption[:237].rstrip() + "…"
        tpl = self.env.get_template("card_template.html")
        return tpl.render(
            headline_html=highlight_keywords(headline),
            headline_size=_dynamic_headline_size(headline),
            caption=caption,
            source_name=article.source_name,
            date=(article.published_at or "")[:10],
            category="IA" if article.media_type == "video" else "TECH",
            media_type=article.media_type,
            has_image=bool(data_uri),
            image_data_uri=data_uri or "",
        )

    # ------------------------------------------------------------------ #
    def render_slide(self, article: Article, image_path: Optional[str],
                     out_png: str | Path) -> bool:
        """Renderiza el slide. Devuelve True si se creó slide.png."""
        out_png = Path(out_png)
        html = self.build_card_html(article, image_path)
        # guardamos también el card.html final usado
        try:
            (out_png.parent / "card.html").write_text(html, encoding="utf-8")
        except Exception:
            pass

        if self.pw_enabled and not self._pw_failed:
            if self._render_with_playwright(html, out_png):
                return True
        # Fallback Pillow
        return self._render_with_pillow(article, image_path, out_png)

    # ----------------------- Playwright ------------------------------- #
    def _ensure_browser(self) -> bool:
        if self._browser is not None:
            return True
        try:
            from playwright.sync_api import sync_playwright
            self._pw_ctx = sync_playwright().start()
            self._browser = self._pw_ctx.chromium.launch(headless=self.pw_headless)
            return True
        except Exception as exc:
            log.warning(f"[yellow]Playwright no disponible para render "
                        f"({exc}); se usa Pillow.[/]")
            self._pw_failed = True
            return False

    def _render_with_playwright(self, html: str, out_png: Path) -> bool:
        if not self._ensure_browser():
            return False
        try:
            page = self._browser.new_page(
                viewport={"width": SLIDE_W, "height": SLIDE_H},
                device_scale_factor=1,
            )
            page.set_content(html, wait_until="networkidle")
            try:
                page.wait_for_timeout(400)
            except Exception:
                pass
            out_png.parent.mkdir(parents=True, exist_ok=True)
            el = page.query_selector(".slide")
            if el:
                el.screenshot(path=str(out_png))
            else:
                page.screenshot(path=str(out_png),
                                clip={"x": 0, "y": 0, "width": SLIDE_W, "height": SLIDE_H})
            page.close()
            return out_png.exists()
        except Exception as exc:
            log.warning(f"[yellow]Screenshot Playwright falló ({exc}); "
                        f"se usa Pillow.[/]")
            self._pw_failed = True
            return False

    # ----------------------- Pillow ----------------------------------- #
    def _render_with_pillow(self, article: Article, image_path: Optional[str],
                            out_png: Path) -> bool:
        try:
            from PIL import Image, ImageDraw, ImageFont, ImageFilter
        except Exception as exc:
            log.error(f"No hay Playwright ni Pillow; no se puede crear slide.png ({exc})")
            return False

        W, H = SLIDE_W, SLIDE_H
        img = Image.new("RGB", (W, H), (10, 14, 26))

        # Fondo: imagen recortada arriba o gradiente tecnológico
        if image_path and Path(image_path).exists():
            try:
                hero = Image.open(image_path).convert("RGB")
                hero = self._cover(hero, W, 800)
                img.paste(hero, (0, 0))
            except Exception:
                self._paint_gradient(img)
        else:
            self._paint_gradient(img)

        draw = ImageDraw.Draw(img, "RGBA")
        # Scrim degradado oscuro inferior
        scrim_top = 520
        for y in range(scrim_top, H):
            alpha = int(250 * (y - scrim_top) / (H - scrim_top))
            draw.line([(0, y), (W, y)], fill=(8, 11, 22, min(alpha, 250)))

        f_brand = self._font(28, bold=True)
        f_head = self._font(_dynamic_headline_size(
            article.short_headline_es or article.title_es or article.title_original) - 4, bold=True)
        f_cap = self._font(32)
        f_foot = self._font(28, bold=True)

        margin = 64
        # Marca arriba
        draw.ellipse([margin, 60, margin + 18, 78], fill=(124, 58, 237, 255))
        draw.text((margin + 30, 56), "TECH · IA", font=f_brand, fill=(255, 255, 255, 255))

        # Titular (desde abajo)
        headline = (article.short_headline_es or article.title_es
                    or article.title_original or "").upper()
        cap = (article.short_caption_es or article.summary_es
               or article.summary_original or "")

        head_lines = self._wrap(draw, headline, f_head, W - 2 * margin)
        cap_lines = self._wrap(draw, cap, f_cap, W - 2 * margin)[:4]

        line_h_head = f_head.size + 12
        line_h_cap = f_cap.size + 10
        footer_h = 70
        block_h = len(head_lines) * line_h_head + 24 + len(cap_lines) * line_h_cap + footer_h
        y = H - margin - block_h

        for ln in head_lines:
            draw.text((margin, y), ln, font=f_head, fill=(255, 255, 255, 255))
            y += line_h_head
        y += 24
        for ln in cap_lines:
            draw.text((margin, y), ln, font=f_cap, fill=(215, 222, 240, 255))
            y += line_h_cap

        # Footer: línea + fuente + fecha
        y += 8
        draw.line([(margin, y), (W - margin, y)], fill=(255, 255, 255, 40), width=2)
        y += 16
        tag = "▶ " if article.media_type == "video" else ""
        draw.text((margin, y), f"{tag}{article.source_name}", font=f_foot,
                  fill=(255, 255, 255, 255))
        date = (article.published_at or "")[:10]
        if date:
            dw = draw.textlength(date, font=f_foot)
            draw.text((W - margin - dw, y), date, font=f_foot, fill=(159, 176, 208, 255))

        out_png.parent.mkdir(parents=True, exist_ok=True)
        img.save(out_png, "PNG")
        return out_png.exists()

    # ----------------------- helpers Pillow --------------------------- #
    @staticmethod
    def _cover(im, w, h):
        from PIL import Image
        sw, sh = im.size
        scale = max(w / sw, h / sh)
        im = im.resize((int(sw * scale), int(sh * scale)), Image.LANCZOS)
        nw, nh = im.size
        left = (nw - w) // 2
        top = (nh - h) // 2
        return im.crop((left, top, left + w, top + h))

    @staticmethod
    def _paint_gradient(img):
        W, H = img.size
        px = img.load()
        for y in range(H):
            t = y / H
            r = int(19 + (10 - 19) * t)
            g = int(26 + (14 - 26) * t)
            b = int(53 + (26 - 53) * t)
            for x in range(0, W, 2):
                px[x, y] = (r, g, b)
                if x + 1 < W:
                    px[x + 1, y] = (r, g, b)
        # toque violeta arriba-izquierda
        from PIL import ImageDraw
        d = ImageDraw.Draw(img, "RGBA")
        d.ellipse([-200, -200, 600, 500], fill=(124, 58, 237, 60))
        d.ellipse([W - 500, -150, W + 200, 450], fill=(29, 78, 216, 50))

    def _font(self, size, bold=False):
        from PIL import ImageFont
        candidates = [
            ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold
             else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
            ("C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf"),
            ("/Library/Fonts/Arial Bold.ttf" if bold else "/Library/Fonts/Arial.ttf"),
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        ]
        for path in candidates:
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
        return ImageFont.load_default()

    @staticmethod
    def _wrap(draw, text, font, max_w):
        if not text:
            return []
        words = text.split()
        lines, cur = [], ""
        for w in words:
            test = (cur + " " + w).strip()
            if draw.textlength(test, font=font) <= max_w:
                cur = test
            else:
                if cur:
                    lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
        return lines

    # ------------------------------------------------------------------ #
    def close(self):
        try:
            if self._browser:
                self._browser.close()
            if self._pw_ctx:
                self._pw_ctx.stop()
        except Exception:
            pass

~~~~

### src\database.py

~~~~python
"""database.py — capa SQLite.

Crea el esquema (runs, sources, articles), guarda noticias y proporciona
funciones de deduplicación:
  - por canonical_url
  - por article_url
  - por hash de título normalizado (content_hash incluye el título)

Diseñada para reutilizarse desde una API (FastAPI) más adelante.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Optional

from .models import Article, Run
from .utils import get_logger, now_utc, iso, title_hash

log = get_logger()


SCHEMA = """
CREATE TABLE IF NOT EXISTS sources (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT UNIQUE NOT NULL,
    trusted       INTEGER DEFAULT 0,
    region        TEXT,
    enabled       INTEGER DEFAULT 1,
    last_seen_at  TEXT
);

CREATE TABLE IF NOT EXISTS runs (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    topic                TEXT,
    language             TEXT,
    requested            INTEGER,
    started_at           TEXT,
    finished_at          TEXT,
    found                INTEGER DEFAULT 0,
    discarded_no_video   INTEGER DEFAULT 0,
    skipped_duplicates   INTEGER DEFAULT 0,
    output_dir           TEXT
);

CREATE TABLE IF NOT EXISTS articles (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id            INTEGER,
    topic             TEXT,
    title_original    TEXT,
    title_es          TEXT,
    summary_original  TEXT,
    summary_es        TEXT,
    short_headline_es TEXT,
    short_caption_es  TEXT,
    language_original TEXT,
    source_name       TEXT,
    source_url        TEXT,
    article_url       TEXT,
    canonical_url     TEXT,
    video_url         TEXT,
    video_embed_url   TEXT,
    video_type        TEXT,
    embed_status      TEXT,
    media_type        TEXT,
    hero_image_url    TEXT,
    video_poster_url  TEXT,
    local_slide_path  TEXT,
    local_media_path  TEXT,
    region            TEXT,
    country           TEXT,
    published_at      TEXT,
    scraped_at        TEXT,
    content_hash      TEXT,
    title_hash        TEXT,
    status            TEXT,
    output_folder     TEXT,
    FOREIGN KEY (run_id) REFERENCES runs (id)
);

CREATE INDEX IF NOT EXISTS idx_articles_canonical ON articles (canonical_url);
CREATE INDEX IF NOT EXISTS idx_articles_articleurl ON articles (article_url);
CREATE INDEX IF NOT EXISTS idx_articles_titlehash  ON articles (title_hash);
CREATE INDEX IF NOT EXISTS idx_articles_contenthash ON articles (content_hash);
"""


class Database:
    def __init__(self, path: str = "data/news.db"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL;")
        self.conn.execute("PRAGMA foreign_keys=ON;")
        self._create_schema()

    # ------------------------------------------------------------------ #
    def _create_schema(self) -> None:
        self.conn.executescript(SCHEMA)
        self.conn.commit()
        self._migrate()

    def _migrate(self) -> None:
        """Añade columnas nuevas a bases de datos antiguas sin perder datos."""
        cur = self.conn.execute("PRAGMA table_info(articles)")
        existing = {row[1] for row in cur.fetchall()}
        wanted = {
            "short_headline_es": "TEXT", "short_caption_es": "TEXT",
            "embed_status": "TEXT", "media_type": "TEXT",
            "hero_image_url": "TEXT", "video_poster_url": "TEXT",
            "local_slide_path": "TEXT", "local_media_path": "TEXT",
            "region": "TEXT", "country": "TEXT",
        }
        for col, ctype in wanted.items():
            if col not in existing:
                try:
                    self.conn.execute(f"ALTER TABLE articles ADD COLUMN {col} {ctype}")
                except Exception:
                    pass
        self.conn.commit()

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:
            pass

    # ---------------------------- sources ----------------------------- #
    def upsert_source(self, name: str, trusted: bool, region: str, enabled: bool) -> None:
        self.conn.execute(
            """
            INSERT INTO sources (name, trusted, region, enabled, last_seen_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(name) DO UPDATE SET
                trusted=excluded.trusted,
                region=excluded.region,
                enabled=excluded.enabled,
                last_seen_at=excluded.last_seen_at
            """,
            (name, int(trusted), region, int(enabled), iso(now_utc())),
        )
        self.conn.commit()

    # ------------------------------ runs ------------------------------ #
    def start_run(self, run: Run) -> int:
        cur = self.conn.execute(
            """
            INSERT INTO runs (topic, language, requested, started_at, output_dir)
            VALUES (?, ?, ?, ?, ?)
            """,
            (run.topic, run.language, run.requested, iso(now_utc()), run.output_dir),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def finish_run(self, run_id: int, found: int, discarded_no_video: int,
                   skipped_duplicates: int, output_dir: Optional[str]) -> None:
        self.conn.execute(
            """
            UPDATE runs SET finished_at=?, found=?, discarded_no_video=?,
                            skipped_duplicates=?, output_dir=?
            WHERE id=?
            """,
            (iso(now_utc()), found, discarded_no_video, skipped_duplicates,
             output_dir, run_id),
        )
        self.conn.commit()

    # ---------------------------- dedup ------------------------------- #
    def is_duplicate(self, article: Article) -> bool:
        """True si la noticia ya existe por canonical_url, article_url o título."""
        th = title_hash(article.title_original or article.title_es)
        cur = self.conn.execute(
            """
            SELECT 1 FROM articles
            WHERE (canonical_url IS NOT NULL AND canonical_url != '' AND canonical_url = ?)
               OR (article_url   IS NOT NULL AND article_url   != '' AND article_url   = ?)
               OR (title_hash    IS NOT NULL AND title_hash    != '' AND title_hash    = ?)
            LIMIT 1
            """,
            (article.canonical_url, article.article_url, th),
        )
        return cur.fetchone() is not None

    # ---------------------------- insert ------------------------------ #
    def insert_article(self, article: Article) -> int:
        row = article.to_db_row()
        row["title_hash"] = title_hash(article.title_original or article.title_es)
        cols = list(row.keys())
        placeholders = ", ".join("?" for _ in cols)
        sql = f"INSERT INTO articles ({', '.join(cols)}) VALUES ({placeholders})"
        cur = self.conn.execute(sql, [row[c] for c in cols])
        self.conn.commit()
        return int(cur.lastrowid)

    def update_article_output(self, article_id: int, folder: str, status: str) -> None:
        self.conn.execute(
            "UPDATE articles SET output_folder=?, status=? WHERE id=?",
            (folder, status, article_id),
        )
        self.conn.commit()

    # ---------------------------- queries ----------------------------- #
    def count_articles(self) -> int:
        return int(self.conn.execute("SELECT COUNT(*) FROM articles").fetchone()[0])

~~~~

### src\exporter.py

~~~~python
"""exporter.py — genera las carpetas de salida, los assets visuales y la galería.

Por cada noticia produce:
    slide.png          (OBLIGATORIO — pieza visual final del carrusel)
    card.html          (HTML usado para el slide)
    embed.html         (reproductor / fallback a poster)
    video_poster.jpg   (si hay poster de video)
    hero_image.jpg     (si hay imagen principal)
    metadata.json, noticia.json, noticia.txt
    source.url, video.url, video_url.txt
    README.txt

En la raíz del run:
    index.html (galería), summary.json, summary.txt
"""
from __future__ import annotations

import base64
import json
import mimetypes
from pathlib import Path
from typing import Optional

import requests
from jinja2 import Environment, FileSystemLoader, select_autoescape

from .models import Article
from .card_renderer import CardRenderer
from .media_extractor import check_embeddable, download_image, youtube_thumbnail
from .utils import get_logger, run_timestamp, now_utc, iso

log = get_logger()


def _img_data_uri(path: Optional[Path]) -> Optional[str]:
    if not path or not Path(path).exists():
        return None
    mime = mimetypes.guess_type(str(path))[0] or "image/jpeg"
    b64 = base64.b64encode(Path(path).read_bytes()).decode("ascii")
    return f"data:{mime};base64,{b64}"


class Exporter:
    def __init__(self, settings: dict, renderer: Optional[CardRenderer] = None,
                 session: Optional[requests.Session] = None,
                 templates_dir: str = "templates"):
        out = (settings or {}).get("output", {})
        vid = (settings or {}).get("video", {})
        self.base_dir = Path(out.get("base_dir", "output"))
        self.prefix = out.get("folder_prefix", "noticia_")
        self.check_embed = vid.get("check_embeddable", True)
        self.download_media = vid.get("download_media", True)
        self.templates_dir = Path(templates_dir)
        self.env = Environment(
            loader=FileSystemLoader(str(self.templates_dir)),
            autoescape=select_autoescape(["html", "xml"]),
        )
        self.renderer = renderer or CardRenderer(settings, templates_dir)
        self.session = session or requests.Session()

    def make_run_dir(self) -> Path:
        run_dir = self.base_dir / run_timestamp()
        run_dir.mkdir(parents=True, exist_ok=True)
        return run_dir

    # ================================================================== #
    def export_article(self, run_dir: Path, index: int, article: Article) -> dict:
        folder = run_dir / f"{self.prefix}{index:02d}"
        folder.mkdir(parents=True, exist_ok=True)

        # --- 1) Descargar media (poster y/o hero image) ----------------- #
        poster_path: Optional[Path] = None
        hero_path: Optional[Path] = None

        if self.download_media:
            if article.media_type == "video":
                poster_src = (article.video_poster_url
                              or youtube_thumbnail(article.video_url or ""))
                if poster_src:
                    p = folder / "video_poster.jpg"
                    if download_image(poster_src, p, self.session):
                        poster_path = p
            if article.hero_image_url:
                h = folder / "hero_image.jpg"
                if download_image(article.hero_image_url, h, self.session):
                    hero_path = h

        # Imagen para el slide: poster (video) > hero > None
        slide_image = poster_path or hero_path
        if slide_image:
            article.local_media_path = str(slide_image)

        # --- 2) ¿El video es embebible? -------------------------------- #
        if article.media_type == "video" and (article.video_embed_url or article.video_url):
            if self.check_embed:
                ok, reason = check_embeddable(
                    article.video_embed_url or article.video_url, self.session)
                article.embed_status = "ok" if ok else "blocked"
                article._embed_reason = reason  # type: ignore
            else:
                article.embed_status = "ok"
        else:
            article.embed_status = "none"

        # --- 3) Render del slide.png (OBLIGATORIO) ---------------------- #
        slide_png = folder / "slide.png"
        created = self.renderer.render_slide(article, str(slide_image) if slide_image else None,
                                             slide_png)
        if created:
            article.local_slide_path = str(slide_png)
        else:
            log.warning(f"[red]No se pudo crear slide.png para noticia_{index:02d}[/]")

        article.output_folder = str(folder)
        article.carousel_text = article.short_caption_es or article.summary_es or ""

        # --- 4) Archivos de datos -------------------------------------- #
        (folder / "noticia.json").write_text(
            json.dumps(article.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        (folder / "metadata.json").write_text(
            json.dumps(self._metadata(article), ensure_ascii=False, indent=2), encoding="utf-8")
        (folder / "noticia.txt").write_text(self._txt(article), encoding="utf-8")
        (folder / "embed.html").write_text(self._render_embed(article, poster_path), encoding="utf-8")
        (folder / "source.url").write_text(
            f"[InternetShortcut]\nURL={article.article_url}\n", encoding="utf-8")
        vurl = article.video_url or article.video_embed_url or ""
        (folder / "video.url").write_text(f"[InternetShortcut]\nURL={vurl}\n", encoding="utf-8")
        # video_url.txt explícito (caso B: video no embebible)
        (folder / "video_url.txt").write_text(vurl + ("\n" if vurl else ""), encoding="utf-8")
        (folder / "README.txt").write_text(self._readme(index, article), encoding="utf-8")

        return self._index_item(folder, run_dir, article)

    # ================================================================== #
    def finalize_run(self, run_dir: Path, run_id, topic: str, items: list[dict],
                     stats: dict) -> None:
        # index.html
        try:
            tpl = self.env.get_template("index_template.html")
            html = tpl.render(run_id=run_id, topic=topic,
                              generated_at=iso(now_utc())[:19].replace("T", " "),
                              items=items)
            (run_dir / "index.html").write_text(html, encoding="utf-8")
        except Exception as exc:
            log.warning(f"No se pudo generar index.html: {exc}")

        # summary.json
        summary = {
            "run_id": run_id,
            "topic": topic,
            "generated_at": iso(now_utc()),
            "output_dir": str(run_dir),
            "stats": stats,
            "items": items,
        }
        (run_dir / "summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

        # summary.txt
        lines = [
            f"Run: {run_id}",
            f"Tema: {topic}",
            f"Carpeta: {run_dir}",
            f"Noticias generadas: {stats.get('found')}/{stats.get('requested')}",
            f"Con video: {stats.get('with_video')}  |  Con imagen: {stats.get('with_image')}",
            f"Embeds bloqueados: {stats.get('embed_blocked')}",
            f"Descartadas sin media: {stats.get('discarded_no_media')}",
            f"Repetidas saltadas: {stats.get('skipped_duplicates')}",
            "",
            "Noticias:",
        ]
        for i, it in enumerate(items, 1):
            lines.append(f"  {i:02d}. [{it['media_type']}] {it['title']}  "
                         f"({it['source_name']})")
        (run_dir / "summary.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

    # ================================================================== #
    @staticmethod
    def _metadata(a: Article) -> dict:
        return {
            "title_es": a.title_es, "title_original": a.title_original,
            "short_headline_es": a.short_headline_es,
            "short_caption_es": a.short_caption_es,
            "summary_es": a.summary_es,
            "language_original": a.language_original,
            "source_name": a.source_name, "country": a.country, "region": a.region,
            "published_at": a.published_at, "scraped_at": a.scraped_at,
            "article_url": a.article_url, "canonical_url": a.canonical_url,
            "media_type": a.media_type,
            "video_url": a.video_url, "video_embed_url": a.video_embed_url,
            "video_type": a.video_type, "embed_status": a.embed_status,
            "embed_reason": getattr(a, "_embed_reason", None),
            "hero_image_url": a.hero_image_url, "video_poster_url": a.video_poster_url,
            "local_slide_path": a.local_slide_path, "local_media_path": a.local_media_path,
            "score": a.score, "score_breakdown": a.score_breakdown,
            "status": a.status,
        }

    @staticmethod
    def _txt(a: Article) -> str:
        return (
            f"Título: {a.title_es or a.title_original}\n"
            f"Titular corto: {a.short_headline_es}\n"
            f"Descripción corta: {a.short_caption_es or a.summary_es or a.summary_original}\n"
            f"Fuente: {a.source_name} ({a.region})\n"
            f"Fecha: {a.published_at or 'N/D'}\n"
            f"Tipo de media: {a.media_type}\n"
            f"Estado embed: {a.embed_status}\n"
            f"Link noticia: {a.article_url}\n"
            f"Link video: {a.video_url or a.video_embed_url or 'N/D'}\n"
            f"Slide: {a.local_slide_path or 'N/D'}\n"
        )

    def _render_embed(self, a: Article, poster_path: Optional[Path]) -> str:
        try:
            tpl = self.env.get_template("embed_template.html")
            return tpl.render(
                title=a.title_es or a.title_original,
                caption=a.short_caption_es or a.summary_es or a.summary_original,
                embed_status=a.embed_status,
                video_embed_url=a.video_embed_url,
                video_url=a.video_url,
                video_type=a.video_type,
                poster_data_uri=_img_data_uri(poster_path),
                article_url=a.article_url,
                source_name=a.source_name,
            )
        except Exception as exc:
            log.debug(f"embed_template falló ({exc})")
            return f"<!doctype html><meta charset=utf-8><p>{a.title_original}</p>"

    @staticmethod
    def _readme(index: int, a: Article) -> str:
        reason = getattr(a, "_embed_reason", None)
        return (
            f"NOTICIA {index:02d}\n{'='*50}\n\n"
            f"slide.png        : pieza visual final 1080x1350 para el carrusel.\n"
            f"card.html        : HTML usado para generar el slide.\n"
            f"embed.html       : reproductor del video (o fallback a poster).\n"
            f"video_poster.jpg : miniatura del video (si existe).\n"
            f"hero_image.jpg   : imagen principal del artículo (si existe).\n"
            f"metadata.json    : metadatos + ranking + estado del embed.\n"
            f"noticia.json     : objeto completo.\n"
            f"noticia.txt      : resumen legible.\n"
            f"source.url       : acceso directo al artículo.\n"
            f"video.url / video_url.txt : enlace directo al video.\n\n"
            f"Título: {a.title_es or a.title_original}\n"
            f"Fuente: {a.source_name} ({a.region})\n"
            f"Tipo de media: {a.media_type}\n"
            f"Estado embed: {a.embed_status}"
            + (f" (motivo: {reason})" if reason else "") + "\n"
            f"Video: {a.video_type or 'N/D'} -> {a.video_url or a.video_embed_url or 'N/D'}\n"
            f"Puntuación: {a.score}  Detalle: {a.score_breakdown}\n"
        )

    @staticmethod
    def _index_item(folder: Path, run_dir: Path, a: Article) -> dict:
        slide_rel = (str((folder / "slide.png").relative_to(run_dir)).replace("\\", "/")
                     if a.local_slide_path else "")
        embed_rel = f"{folder.name}/embed.html"
        return {
            "folder": folder.name,
            "slide_rel": slide_rel,
            "title": a.title_es or a.title_original,
            "source_name": a.source_name,
            "date": (a.published_at or "")[:10],
            "media_type": a.media_type,
            "embed_status": a.embed_status,
            "article_url": a.article_url,
            "video_url": a.video_url or a.video_embed_url or "",
            "has_embed": a.media_type == "video",
            "embed_rel": embed_rel,
        }

~~~~

### src\media_extractor.py

~~~~python
"""media_extractor.py — extracción de imágenes/posters y chequeo de embed.

Responsabilidades:
  - extract_hero_image(): imagen principal del artículo (og:image, twitter:image,
    JSON-LD image, primera imagen grande del contenido).
  - extract_video_poster(): thumbnail del video (JSON-LD VideoObject.thumbnailUrl,
    og:image como respaldo).
  - check_embeddable(): determina si una URL de video se puede meter en un iframe,
    inspeccionando cabeceras X-Frame-Options y Content-Security-Policy
    (frame-ancestors). Los hosts conocidos (YouTube, Vimeo, Dailymotion) se
    consideran embebibles.
  - download_image(): descarga una imagen y la guarda como JPG (con Pillow si está
    disponible; si no, guarda el binario tal cual).

No descarga videos protegidos: solo imágenes/posters públicos y referencias.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Optional

import requests
from bs4 import BeautifulSoup

from .utils import absolutize, get_logger

log = get_logger()

# Hosts cuyo /embed permite framing de forma fiable.
_EMBEDDABLE_HOSTS = ("youtube.com/embed", "youtube-nocookie.com/embed",
                     "player.vimeo.com", "dailymotion.com/embed",
                     "players.brightcove.net", "player.twitch.tv")


# --------------------------------------------------------------------------- #
# Imágenes
# --------------------------------------------------------------------------- #
def _meta_content(soup: BeautifulSoup, *keys: str) -> Optional[str]:
    for key in keys:
        tag = (soup.find("meta", attrs={"property": key})
               or soup.find("meta", attrs={"name": key}))
        if tag and tag.get("content"):
            return tag["content"].strip()
    return None


def extract_hero_image(soup: BeautifulSoup, base_url: str) -> Optional[str]:
    """Devuelve la URL de la imagen principal del artículo, o None."""
    url = _meta_content(soup, "og:image", "og:image:url", "og:image:secure_url",
                        "twitter:image", "twitter:image:src")
    if url:
        return absolutize(base_url, url)

    # JSON-LD: image puede ser str, dict{url} o lista
    for tag in soup.find_all("script", type="application/ld+json"):
        if not tag.string:
            continue
        try:
            data = json.loads(tag.string)
        except Exception:
            continue
        found = _jsonld_image(data)
        if found:
            return absolutize(base_url, found)

    # Primera <img> razonablemente grande dentro de <article> o del cuerpo
    container = soup.find("article") or soup
    for img in container.find_all("img"):
        src = img.get("src") or img.get("data-src") or ""
        if not src or src.startswith("data:"):
            continue
        if re.search(r"(sprite|logo|icon|avatar|placeholder|1x1|pixel)", src, re.I):
            continue
        return absolutize(base_url, src)
    return None


def _jsonld_image(data) -> Optional[str]:
    if isinstance(data, dict):
        if "image" in data:
            img = data["image"]
            if isinstance(img, str):
                return img
            if isinstance(img, dict):
                return img.get("url")
            if isinstance(img, list) and img:
                first = img[0]
                return first.get("url") if isinstance(first, dict) else first
        for v in data.values():
            r = _jsonld_image(v)
            if r:
                return r
    elif isinstance(data, list):
        for item in data:
            r = _jsonld_image(item)
            if r:
                return r
    return None


def extract_video_poster(soup: BeautifulSoup, base_url: str) -> Optional[str]:
    """Devuelve un poster/thumbnail del video (JSON-LD o og:image)."""
    for tag in soup.find_all("script", type="application/ld+json"):
        if not tag.string:
            continue
        try:
            data = json.loads(tag.string)
        except Exception:
            continue
        thumb = _jsonld_thumbnail(data)
        if thumb:
            return absolutize(base_url, thumb)
    # respaldo: og:image
    return extract_hero_image(soup, base_url)


def _jsonld_thumbnail(data) -> Optional[str]:
    if isinstance(data, dict):
        t = data.get("@type", "")
        types = t if isinstance(t, list) else [t]
        if any("VideoObject" in str(x) for x in types):
            thumb = data.get("thumbnailUrl") or data.get("thumbnail")
            if isinstance(thumb, list) and thumb:
                thumb = thumb[0]
            if isinstance(thumb, dict):
                thumb = thumb.get("url")
            if thumb:
                return thumb
        if "@graph" in data:
            r = _jsonld_thumbnail(data["@graph"])
            if r:
                return r
    elif isinstance(data, list):
        for item in data:
            r = _jsonld_thumbnail(item)
            if r:
                return r
    return None


def youtube_thumbnail(video_url: str) -> Optional[str]:
    """Construye la miniatura de YouTube a partir del ID."""
    m = re.search(r"(?:v=|youtu\.be/|embed/)([A-Za-z0-9_\-]{6,})", video_url or "")
    if m:
        return f"https://i.ytimg.com/vi/{m.group(1)}/hqdefault.jpg"
    return None


# --------------------------------------------------------------------------- #
# ¿Embebible?
# --------------------------------------------------------------------------- #
def check_embeddable(embed_url: str, session: Optional[requests.Session] = None,
                     timeout: int = 15) -> tuple[bool, str]:
    """Devuelve (embebible, motivo).

    motivo: "ok" | "x_frame_options:DENY" | "csp_frame_ancestors" |
            "host_known_embeddable" | "unreachable" | "no_url"
    """
    if not embed_url:
        return False, "no_url"

    low = embed_url.lower()
    if any(h in low for h in _EMBEDDABLE_HOSTS):
        return True, "host_known_embeddable"

    sess = session or requests
    try:
        resp = sess.get(embed_url, timeout=timeout, stream=True,
                        headers={"User-Agent": "Mozilla/5.0"})
        xfo = resp.headers.get("X-Frame-Options", "").upper()
        csp = resp.headers.get("Content-Security-Policy", "").lower()
        try:
            resp.close()
        except Exception:
            pass
        if "DENY" in xfo:
            return False, "x_frame_options:DENY"
        if "SAMEORIGIN" in xfo:
            return False, "x_frame_options:SAMEORIGIN"
        if "frame-ancestors" in csp:
            # si frame-ancestors no incluye 'self'/* abierto, lo tratamos como bloqueado
            m = re.search(r"frame-ancestors([^;]*)", csp)
            directive = m.group(1).strip() if m else ""
            if "*" not in directive:
                return False, "csp_frame_ancestors"
        return True, "ok"
    except requests.RequestException:
        # Si no podemos comprobarlo, somos conservadores: tratamos como bloqueado
        # para forzar el fallback a poster/imagen (más robusto visualmente).
        return False, "unreachable"


# --------------------------------------------------------------------------- #
# Descarga de imágenes
# --------------------------------------------------------------------------- #
def download_image(url: str, dest_path: str | Path,
                   session: Optional[requests.Session] = None,
                   timeout: int = 20, max_side: int = 1600) -> bool:
    """Descarga una imagen y la guarda como JPG en dest_path. True si éxito."""
    if not url:
        return False
    dest = Path(dest_path)
    sess = session or requests
    try:
        resp = sess.get(url, timeout=timeout,
                        headers={"User-Agent": "Mozilla/5.0"})
        if resp.status_code != 200 or not resp.content:
            return False
        raw = resp.content
    except requests.RequestException as exc:
        log.debug(f"No se pudo descargar imagen {url}: {exc}")
        return False

    # Intentar normalizar con Pillow → JPG
    try:
        import io
        from PIL import Image
        img = Image.open(io.BytesIO(raw))
        img = img.convert("RGB")
        w, h = img.size
        if max(w, h) > max_side:
            scale = max_side / max(w, h)
            img = img.resize((int(w * scale), int(h * scale)))
        dest.parent.mkdir(parents=True, exist_ok=True)
        img.save(dest, "JPEG", quality=88)
        return True
    except Exception as exc:
        log.debug(f"Pillow no pudo procesar imagen ({exc}); se guarda binario.")
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(raw)
            return True
        except Exception:
            return False

~~~~

### src\models.py

~~~~python
"""models.py — estructuras de datos del proyecto (dataclasses).

Pensadas para ser fáciles de serializar a JSON y de mapear a la base de datos,
y para poder reutilizarse luego desde una API FastAPI o una app Flutter.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional


@dataclass
class Source:
    """Una fuente de noticias configurada en sources.yaml."""
    name: str
    enabled: bool = True
    trusted: bool = False
    region: str = "Global"
    listing_urls: list[str] = field(default_factory=list)
    rss: Optional[str] = None
    article_pattern: Optional[str] = None
    needs_js: bool = False

    @classmethod
    def from_dict(cls, d: dict) -> "Source":
        return cls(
            name=d.get("name", "Desconocida"),
            enabled=bool(d.get("enabled", True)),
            trusted=bool(d.get("trusted", False)),
            region=d.get("region", "Global"),
            listing_urls=list(d.get("listing_urls", []) or []),
            rss=d.get("rss"),
            article_pattern=d.get("article_pattern"),
            needs_js=bool(d.get("needs_js", False)),
        )


@dataclass
class VideoInfo:
    """Información del video detectado en un artículo."""
    found: bool = False
    video_type: Optional[str] = None        # youtube | vimeo | html5 | og_video | jsonld | iframe ...
    video_url: Optional[str] = None         # URL "pública" del video (página/watch)
    video_embed_url: Optional[str] = None   # URL para embeber en un iframe
    related: bool = True                    # ¿parece directamente relacionado con la noticia?


@dataclass
class Article:
    """Una noticia procesada, lista para guardar y exportar."""
    # Identificación
    run_id: Optional[int] = None
    topic: str = ""

    # Contenido (original + traducido)
    title_original: str = ""
    title_es: str = ""
    summary_original: str = ""
    summary_es: str = ""
    language_original: str = "und"

    # Textos cortos para la pieza visual
    short_headline_es: str = ""   # titular corto en MAYÚSCULAS para el slide
    short_caption_es: str = ""    # descripción de 2-4 líneas para el slide

    # Fuente / enlaces
    source_name: str = ""
    source_url: str = ""        # URL de la fuente (listado/portada)
    article_url: str = ""       # URL del artículo
    canonical_url: str = ""     # URL canónica/limpia del artículo

    # Video
    video_url: Optional[str] = None
    video_embed_url: Optional[str] = None
    video_type: Optional[str] = None
    embed_status: str = "none"  # ok | blocked | none  (¿se puede embeber el video?)

    # Imagen / media
    media_type: str = "none"            # video | image | none
    hero_image_url: Optional[str] = None
    video_poster_url: Optional[str] = None
    local_slide_path: Optional[str] = None   # ruta a slide.png
    local_media_path: Optional[str] = None   # ruta a hero_image.jpg / video_poster.jpg

    # Metadatos
    region: str = "Global"
    country: str = ""
    published_at: Optional[str] = None   # ISO 8601
    scraped_at: Optional[str] = None     # ISO 8601
    content_hash: str = ""
    status: str = "candidate"            # candidate | selected | exported | skipped_duplicate | no_video
    output_folder: Optional[str] = None

    # Ranking / texto carrusel (no se persisten todos en DB, pero viajan en el objeto)
    score: int = 0
    score_breakdown: dict = field(default_factory=dict)
    carousel_text: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    # ---- Mapeo a/desde la tabla articles -------------------------------- #
    DB_COLUMNS = [
        "run_id", "topic", "title_original", "title_es", "summary_original",
        "summary_es", "short_headline_es", "short_caption_es",
        "language_original", "source_name", "source_url", "article_url",
        "canonical_url", "video_url", "video_embed_url", "video_type",
        "embed_status", "media_type", "hero_image_url", "video_poster_url",
        "local_slide_path", "local_media_path", "region", "country",
        "published_at", "scraped_at", "content_hash", "status", "output_folder",
    ]

    def to_db_row(self) -> dict:
        d = self.to_dict()
        return {k: d.get(k) for k in self.DB_COLUMNS}


@dataclass
class Run:
    """Una ejecución del programa."""
    id: Optional[int] = None
    topic: str = ""
    language: str = "es"
    requested: int = 5
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    found: int = 0
    discarded_no_video: int = 0
    skipped_duplicates: int = 0
    output_dir: Optional[str] = None

~~~~

### src\ranker.py

~~~~python
"""ranker.py — puntuación estricta para elegir las mejores noticias Tech/IA.

IMPORTANTE: ninguna noticia puede llegar al top si no pasó el filtro temático
(`is_valid_tech_ai_news`). Eso se marca con `article._topic_valid` y se respeta
en `passes()`. El filtro se aplica en app.py ANTES del ranking.

Puntos (configurables en settings.yaml -> ranking.weights):
  +5 IA / ML / modelos / robots / chips
  +4 tecnología futurista
  +3 video o imagen usable
  +3 video claro
  +3 fuente tecnológica confiable
  +2 reciente
  +2 impacto global
  +2 dispositivos / avances visuales
  -10 política general
  -8  economía general sin tecnología
  -10 crimen / farándula / deportes
  -5  título ambiguo sin tema tech
  -10 repetida
"""
from __future__ import annotations

import re

from .models import Article
from .utils import age_in_days, get_logger

log = get_logger()


_AI_KEYWORDS = [
    r"\bia\b", "inteligencia artificial", "artificial intelligence",
    "machine learning", "aprendizaje autom", "deep learning", "redes neuronales",
    "neural network", "modelo de lenguaje", "language model", r"\bllm\b",
    "chatgpt", "openai", "anthropic", "claude", "gemini", "deepmind",
    "chip", "semiconductor", "gpu", "nvidia", "algoritmo", "algorithm",
]

_FUTURISTIC_KEYWORDS = [
    "cuántic", "quantum", "humanoid", "humanoide", "agi",
    "autónom", "autonomous", "exoesqueleto", "holograma", "metaverso",
    "biotec", "nanotec", "fusion nuclear", "neuralink", "brain-computer",
    "interfaz cerebro", "drone", "dron", "satélite", "space", "espacial",
]

_VISUAL_DEVICE_KEYWORDS = [
    "robot", "device", "dispositivo", "gadget", "wearable", "smartphone",
    "gafas", "glasses", "headset", "realidad virtual", "realidad aumentada",
    r"\bvr\b", r"\bar\b", "prototip", "unveil", "presenta", "lanza", "muestra",
    "demo", "prototype",
]

_GLOBAL_KEYWORDS = [
    "global", "world", "mundial", "international", "internacional", "europe",
    "europa", "china", "estados unidos", "united states", "worldwide",
    "billion", "millones de usuarios",
]

# Penalizaciones temáticas (refuerzan al filtro; suelen descartarse antes)
_POLITICAL = ["elecciones", "presidente", "gobierno", "congreso",
              "partido polít", "campaña electoral", "escándalo polít"]
_ECONOMY = ["bolsa de valores", "inflación", "mercados bursátiles",
            "acciones de la bolsa", "pib", "tipos de interés"]
_TABLOID = ["crimen", "asesinato", "fútbol", "deporte", "farándula",
            "celebridad", "religión", "guerra", "conflicto armado"]

_TECH_ANY = _AI_KEYWORDS + _FUTURISTIC_KEYWORDS + _VISUAL_DEVICE_KEYWORDS + [
    "tecnología", "tech", "software", "hardware", "ciberseguridad",
    "cybersecurity", "startup", "innovación", "app", "data center",
]


def _has(text: str, patterns: list[str]) -> bool:
    if not text:
        return False
    low = text.lower()
    return any(re.search(p, low) for p in patterns)


def _count(text: str, patterns: list[str]) -> int:
    if not text:
        return 0
    low = text.lower()
    return sum(1 for p in patterns if re.search(p, low))


class Ranker:
    def __init__(self, settings: dict):
        rk = (settings or {}).get("ranking", {})
        self.min_score = rk.get("min_score", 1)
        w = rk.get("weights", {}) or {}
        self.w = {
            "keyword_ai": w.get("keyword_ai", 5),
            "futuristic_tech": w.get("futuristic_tech", 4),
            "has_usable_media": w.get("has_usable_media", 3),
            "has_clear_video": w.get("has_clear_video", 3),
            "trusted_source": w.get("trusted_source", 3),
            "recent": w.get("recent", 2),
            "global_impact": w.get("global_impact", 2),
            "visual_devices": w.get("visual_devices", 2),
            "political": w.get("political", -10),
            "economy_no_tech": w.get("economy_no_tech", -8),
            "tabloid_sports_crime": w.get("tabloid_sports_crime", -10),
            "ambiguous_no_tech": w.get("ambiguous_no_tech", -5),
            "repeated": w.get("repeated", -10),
        }
        self.max_age_recent_days = 7

    def score(self, article: Article, *, trusted: bool, is_duplicate: bool,
              published_dt=None) -> Article:
        breakdown: dict[str, int] = {}
        text = " ".join(filter(None, [
            article.title_original, article.title_es,
            article.summary_original, article.summary_es,
        ]))

        # + IA
        if _has(text, _AI_KEYWORDS):
            breakdown["keyword_ai"] = self.w["keyword_ai"]
        # + tecnología futurista
        if _has(text, _FUTURISTIC_KEYWORDS):
            breakdown["futuristic_tech"] = self.w["futuristic_tech"]
        # + dispositivos / avances visuales
        if _has(text, _VISUAL_DEVICE_KEYWORDS):
            breakdown["visual_devices"] = self.w["visual_devices"]

        # + media usable
        if article.media_type in ("video", "image") or article.hero_image_url:
            breakdown["has_usable_media"] = self.w["has_usable_media"]
        # + video claro
        if article.video_url or article.video_embed_url:
            if article.video_type in ("youtube", "vimeo", "dailymotion",
                                      "html5", "jsonld", "og_video"):
                breakdown["has_clear_video"] = self.w["has_clear_video"]
            else:
                breakdown["has_clear_video"] = max(1, self.w["has_clear_video"] // 2)

        # + fuente confiable
        if trusted:
            breakdown["trusted_source"] = self.w["trusted_source"]
        # + reciente
        age = age_in_days(published_dt)
        if age is not None and age <= self.max_age_recent_days:
            breakdown["recent"] = self.w["recent"]
        elif age is not None and age <= 21:
            breakdown["recent"] = max(1, self.w["recent"] // 2)
        # + impacto global
        if _has(text, _GLOBAL_KEYWORDS):
            breakdown["global_impact"] = self.w["global_impact"]

        # - penalizaciones temáticas
        if _has(text, _POLITICAL):
            breakdown["political"] = self.w["political"]
        if _has(text, _ECONOMY) and not _has(text, _TECH_ANY):
            breakdown["economy_no_tech"] = self.w["economy_no_tech"]
        if _has(text, _TABLOID):
            breakdown["tabloid_sports_crime"] = self.w["tabloid_sports_crime"]
        if not _has(text, _TECH_ANY):
            breakdown["ambiguous_no_tech"] = self.w["ambiguous_no_tech"]

        # - repetida
        if is_duplicate:
            breakdown["repeated"] = self.w["repeated"]

        article.score = sum(breakdown.values())
        article.score_breakdown = breakdown
        return article

    def passes(self, article: Article) -> bool:
        # GATE DURO: si no pasó el filtro temático, jamás entra al top.
        if getattr(article, "_topic_valid", True) is False:
            return False
        return article.score >= self.min_score

    @staticmethod
    def sort_best(articles: list[Article]) -> list[Article]:
        # Seguridad extra: excluir cualquiera marcado como no válido temáticamente.
        valid = [a for a in articles if getattr(a, "_topic_valid", True) is not False]
        return sorted(valid, key=lambda a: a.score, reverse=True)

~~~~

### src\scraper.py

~~~~python
"""scraper.py — descarga de listados y artículos.

Flujo por fuente:
  1. Si la fuente tiene RSS, se leen los enlaces del feed (preferido: estable y
     respetuoso).
  2. Si no, se descarga cada listing_url y se extraen enlaces de artículos que
     coincidan con article_pattern.
  3. Cada artículo se descarga (requests; Playwright solo si needs_js o si
     requests no encuentra video), se extraen metadatos y se busca video.

Principios de respeto:
  - Se consulta robots.txt (si respect_robots_txt=true) y se omiten URLs no
    permitidas.
  - No se intenta saltar paywalls, captchas, logins ni DRM.
  - Hay pausas entre peticiones (delay_between_requests).
  - Cualquier fallo de una fuente/artículo NO detiene el proceso global.
"""
from __future__ import annotations

import time
import xml.etree.ElementTree as ET
from typing import Optional
from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

from .models import Article, Source, VideoInfo
from .video_detector import detect_video
from .media_extractor import (extract_hero_image, extract_video_poster,
                              youtube_thumbnail)
from .translator import detect_language
from .utils import (absolutize, canonical_url, get_logger, iso, now_utc,
                    parse_date, age_in_days)

log = get_logger()


class Scraper:
    def __init__(self, settings: dict):
        s = (settings or {}).get("search", {})
        self.timeout = s.get("request_timeout", 20)
        self.retries = s.get("retries", 2)
        self.delay = s.get("delay_between_requests", 1.0)
        self.max_per_source = s.get("max_articles_per_source", 25)
        self.max_age_days = s.get("max_age_days", 21)
        self.respect_robots = s.get("respect_robots_txt", True)
        self.user_agent = s.get("user_agent",
                                "TechNewsVideoScraper/1.0 (+local research tool)")

        pw = (settings or {}).get("playwright", {})
        self.pw_enabled = pw.get("enabled", True)
        self.pw_headless = pw.get("headless", True)
        self.pw_nav_timeout = pw.get("nav_timeout", 25000)

        vid = (settings or {}).get("video", {})
        self.accept_types = vid.get("accept_types")

        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": self.user_agent,
            "Accept-Language": "es,en;q=0.8",
        })
        self._robots_cache: dict[str, Optional[RobotFileParser]] = {}
        self._playwright = None  # se inicia perezosamente

    # ================================================================== #
    # robots.txt
    # ================================================================== #
    def _robots_for(self, url: str) -> Optional[RobotFileParser]:
        if not self.respect_robots:
            return None
        netloc = urlparse(url).netloc
        if netloc in self._robots_cache:
            return self._robots_cache[netloc]
        rp = RobotFileParser()
        robots_url = f"{urlparse(url).scheme}://{netloc}/robots.txt"
        try:
            resp = self.session.get(robots_url, timeout=self.timeout)
            if resp.status_code == 200:
                rp.parse(resp.text.splitlines())
            else:
                rp = None
        except Exception:
            rp = None
        self._robots_cache[netloc] = rp
        return rp

    def _allowed(self, url: str) -> bool:
        if not self.respect_robots:
            return True
        rp = self._robots_for(url)
        if rp is None:
            return True  # sin robots.txt accesible → asumimos permitido
        try:
            return rp.can_fetch(self.user_agent, url)
        except Exception:
            return True

    # ================================================================== #
    # HTTP
    # ================================================================== #
    def _get(self, url: str) -> Optional[str]:
        if not self._allowed(url):
            log.info(f"[yellow]robots.txt no permite:[/] {url}")
            return None
        for attempt in range(self.retries + 1):
            try:
                resp = self.session.get(url, timeout=self.timeout)
                if resp.status_code == 200:
                    return resp.text
                if resp.status_code in (401, 403):
                    log.info(f"[yellow]Bloqueado ({resp.status_code}), se omite:[/] {url}")
                    return None
                if resp.status_code == 404:
                    return None
            except requests.RequestException as exc:
                log.debug(f"Intento {attempt+1} falló para {url}: {exc}")
            time.sleep(self.delay)
        return None

    def _get_rendered(self, url: str) -> Optional[str]:
        """Renderiza con Playwright (solo cuando hace falta JavaScript)."""
        if not self.pw_enabled:
            return None
        if not self._allowed(url):
            return None
        try:
            if self._playwright is None:
                from playwright.sync_api import sync_playwright
                self._pw_ctx = sync_playwright().start()
                self._browser = self._pw_ctx.chromium.launch(headless=self.pw_headless)
                self._playwright = True
            page = self._browser.new_page(user_agent=self.user_agent)
            page.goto(url, timeout=self.pw_nav_timeout, wait_until="domcontentloaded")
            try:
                page.wait_for_timeout(1500)
            except Exception:
                pass
            html = page.content()
            page.close()
            return html
        except Exception as exc:
            log.debug(f"Playwright falló para {url}: {exc}")
            return None

    def close(self) -> None:
        try:
            if self._playwright:
                self._browser.close()
                self._pw_ctx.stop()
        except Exception:
            pass

    # ================================================================== #
    # Listados
    # ================================================================== #
    def collect_article_urls(self, source: Source) -> list[str]:
        urls: list[str] = []
        # 1) RSS preferido
        if source.rss:
            urls.extend(self._urls_from_rss(source.rss))
        # 2) Listados HTML
        if len(urls) < self.max_per_source:
            for listing in source.listing_urls:
                urls.extend(self._urls_from_listing(listing, source))
                if len(urls) >= self.max_per_source:
                    break
        # dedup conservando orden
        seen, out = set(), []
        for u in urls:
            cu = canonical_url(u)
            if cu and cu not in seen:
                seen.add(cu)
                out.append(u)
        return out[: self.max_per_source]

    def _urls_from_rss(self, rss_url: str) -> list[str]:
        xml = self._get(rss_url)
        if not xml:
            return []
        out: list[str] = []
        try:
            root = ET.fromstring(xml.encode("utf-8", errors="ignore"))
        except Exception:
            return []
        # RSS 2.0: channel/item/link  |  Atom: entry/link[@href]
        for item in root.iter():
            tag = item.tag.lower()
            if tag.endswith("item") or tag.endswith("entry"):
                link = None
                for child in item:
                    ctag = child.tag.lower()
                    if ctag.endswith("link"):
                        link = child.get("href") or (child.text or "").strip()
                        if link:
                            break
                if link:
                    out.append(link)
        return out

    def _urls_from_listing(self, listing_url: str, source: Source) -> list[str]:
        html = self._get(listing_url)
        if not html and source.needs_js:
            html = self._get_rendered(listing_url)
        if not html:
            return []
        soup = BeautifulSoup(html, "html.parser")
        out: list[str] = []
        for a in soup.find_all("a", href=True):
            href = absolutize(listing_url, a["href"])
            if source.article_pattern and source.article_pattern not in href:
                continue
            if "#" in href and href.split("#")[0] == listing_url:
                continue
            out.append(href)
        return out

    # ================================================================== #
    # Artículo individual
    # ================================================================== #
    def fetch_article(self, url: str, source: Source, topic: str) -> Optional[Article]:
        """Descarga y procesa un artículo. Devuelve un Article candidato o None.

        None significa: sin contenido / bloqueado. (La ausencia de video se
        refleja en el Article con status 'no_video'.)
        """
        html = self._get(url)
        if not html and source.needs_js:
            html = self._get_rendered(url)
        if not html:
            return None

        soup = BeautifulSoup(html, "html.parser")
        title = self._extract_title(soup)
        summary = self._extract_summary(soup)
        published = self._extract_date(soup)
        canon = self._extract_canonical(soup, url)

        if not title:
            return None

        # ¿demasiado vieja?
        if self.max_age_days and published is not None:
            age = age_in_days(published)
            if age is not None and age > self.max_age_days:
                log.debug(f"Descartada por antigüedad ({age:.0f}d): {title[:60]}")
                return None

        # Detección de video (requests). Si no hay y la fuente puede usar JS,
        # reintentamos con render para no perder videos cargados dinámicamente.
        video = detect_video(html, url, self.accept_types)
        if not video.found and self.pw_enabled and not source.needs_js:
            rendered = self._get_rendered(url)
            if rendered:
                video = detect_video(rendered, url, self.accept_types)
                if rendered:
                    soup = BeautifulSoup(rendered, "html.parser")

        # Media: imagen principal (hero) y poster del video
        hero_image_url = extract_hero_image(soup, url)
        video_poster_url = None
        if video.found:
            video_poster_url = (extract_video_poster(soup, url)
                                or youtube_thumbnail(video.video_url or ""))
            media_type = "video"
        elif hero_image_url:
            media_type = "image"
        else:
            media_type = "none"

        lang = detect_language(f"{title}. {summary}")

        article = Article(
            topic=topic,
            title_original=title,
            summary_original=summary,
            language_original=lang,
            source_name=source.name,
            source_url=source.listing_urls[0] if source.listing_urls else (source.rss or ""),
            article_url=url,
            canonical_url=canon or canonical_url(url),
            video_url=video.video_url,
            video_embed_url=video.video_embed_url,
            video_type=video.video_type,
            media_type=media_type,
            hero_image_url=hero_image_url,
            video_poster_url=video_poster_url,
            region=source.region,
            country=source.region,
            published_at=iso(published),
            scraped_at=iso(now_utc()),
            status="candidate" if video.found else ("image" if media_type == "image" else "no_video"),
        )
        if not video.related:
            setattr(article, "_video_unrelated", True)
        # guardamos el datetime para el ranking sin re-parsear
        setattr(article, "_published_dt", published)
        return article

    # ----------------------- extractores ----------------------------- #
    @staticmethod
    def _meta(soup: BeautifulSoup, *keys: str) -> Optional[str]:
        for key in keys:
            tag = (soup.find("meta", attrs={"property": key})
                   or soup.find("meta", attrs={"name": key}))
            if tag and tag.get("content"):
                return tag["content"].strip()
        return None

    def _extract_title(self, soup: BeautifulSoup) -> str:
        return (self._meta(soup, "og:title", "twitter:title")
                or (soup.title.string.strip() if soup.title and soup.title.string else "")
                or (soup.find("h1").get_text(strip=True) if soup.find("h1") else ""))

    def _extract_summary(self, soup: BeautifulSoup) -> str:
        return (self._meta(soup, "og:description", "twitter:description", "description")
                or "")

    def _extract_date(self, soup: BeautifulSoup):
        raw = (self._meta(soup, "article:published_time", "og:article:published_time",
                          "datePublished", "publishdate", "date")
               )
        if not raw:
            t = soup.find("time")
            if t:
                raw = t.get("datetime") or t.get_text(strip=True)
        return parse_date(raw)

    @staticmethod
    def _extract_canonical(soup: BeautifulSoup, url: str) -> str:
        link = soup.find("link", attrs={"rel": "canonical"})
        if link and link.get("href"):
            return canonical_url(link["href"])
        return canonical_url(url)

~~~~

### src\source_loader.py

~~~~python
"""source_loader.py — carga y valida las fuentes de config/sources.yaml."""
from __future__ import annotations

from pathlib import Path

from .models import Source
from .utils import load_yaml, get_logger

log = get_logger()


def load_sources(path: str = "config/sources.yaml", only_enabled: bool = True) -> list[Source]:
    """Lee sources.yaml y devuelve una lista de objetos Source.

    Las fuentes confiables (trusted=True) se ordenan primero, para
    "intentar primero fuentes confiables".
    """
    data = load_yaml(path)
    raw = data.get("sources", []) if isinstance(data, dict) else []
    sources: list[Source] = []

    for item in raw:
        if not isinstance(item, dict) or not item.get("name"):
            continue
        src = Source.from_dict(item)
        if only_enabled and not src.enabled:
            continue
        # Una fuente es útil solo si tiene RSS o algún listing_url.
        if not src.rss and not src.listing_urls:
            log.warning(f"[yellow]Fuente sin RSS ni listing_urls, se omite:[/] {src.name}")
            continue
        sources.append(src)

    # Confiables primero; dentro de cada grupo se mantiene el orden del archivo.
    sources.sort(key=lambda s: (not s.trusted))

    if not sources:
        log.warning("No se cargó ninguna fuente válida desde sources.yaml")
    else:
        log.info(f"Fuentes cargadas: {len(sources)} "
                 f"({sum(1 for s in sources if s.trusted)} confiables)")
    return sources

~~~~

### src\telegram_sender.py

~~~~python
"""telegram_sender.py — envía los slides generados a Telegram.

Controlado por variables de entorno (.env):
    TELEGRAM_ENABLED        true/false
    TELEGRAM_BOT_TOKEN      token del bot
    TELEGRAM_CHAT_ID        chat/canal destino
    TELEGRAM_SEND_AS_ALBUM  true/false (álbum con sendMediaGroup)

Comportamiento robusto:
  - Si faltan variables → "[TELEGRAM] No configurado. Se omite envío."
  - Si está desactivado → "[TELEGRAM] Desactivado por TELEGRAM_ENABLED=false"
  - Álbum vía sendMediaGroup; si falla, fallback a sendPhoto uno por uno.
  - Nunca lanza excepción que detenga el programa.
"""
from __future__ import annotations

import html
import json
import os
from pathlib import Path
from typing import Any, Optional

import requests

from .utils import get_logger

log = get_logger()

API = "https://api.telegram.org/bot{token}/{method}"
CAPTION_LIMIT = 1024


def _truthy(val: Optional[str]) -> bool:
    return str(val).strip().lower() in ("1", "true", "yes", "on", "si", "sí")


def _get(article: Any, key: str, default=""):
    if isinstance(article, dict):
        return article.get(key, default)
    return getattr(article, key, default)


def _slide_path(run_output_dir: Path, index: int, article: Any) -> Optional[Path]:
    # 1) ruta guardada en el artículo
    p = _get(article, "local_slide_path", "")
    if p and Path(p).exists():
        return Path(p)
    # 2) ruta estándar noticia_XX/slide.png
    cand = run_output_dir / f"noticia_{index:02d}" / "slide.png"
    return cand if cand.exists() else None


def _caption(index: int, article: Any) -> str:
    title = _get(article, "short_headline_es") or _get(article, "title_es") \
        or _get(article, "title_original") or "Sin título"
    source = _get(article, "source_name", "")
    url = _get(article, "article_url", "")
    parts = [f"<b>#{index} · {html.escape(str(title))}</b>"]
    if source:
        parts.append(f"📰 {html.escape(str(source))}")
    if url:
        parts.append(f'🔗 <a href="{html.escape(str(url))}">Ver artículo</a>')
    cap = "\n".join(parts)
    return cap[:CAPTION_LIMIT]


# --------------------------------------------------------------------------- #
def send_run_to_telegram(run_output_dir, articles: list) -> str:
    """Envía los slides del run a Telegram. Devuelve un estado legible.

    Estados: "sent" | "partial" | "not_configured" | "disabled" | "no_slides" | "error"
    """
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except Exception:
        pass  # si no está python-dotenv, se usan las variables del entorno tal cual

    enabled_raw = os.getenv("TELEGRAM_ENABLED")
    if enabled_raw is not None and not _truthy(enabled_raw):
        log.info("[TELEGRAM] Desactivado por TELEGRAM_ENABLED=false")
        return "disabled"

    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id or token.startswith("pon_aqui") or chat_id.startswith("pon_aqui"):
        log.info("[TELEGRAM] No configurado. Se omite envío.")
        return "not_configured"

    as_album = _truthy(os.getenv("TELEGRAM_SEND_AS_ALBUM", "true"))
    run_output_dir = Path(run_output_dir)

    # Recolectar slides + captions
    items: list[tuple[Path, str]] = []
    for i, article in enumerate(articles, start=1):
        sp = _slide_path(run_output_dir, i, article)
        if sp:
            items.append((sp, _caption(i, article)))

    if not items:
        log.info("[TELEGRAM] No hay slides para enviar.")
        return "no_slides"

    ok = False
    if as_album and len(items) > 1:
        ok = _send_album(token, chat_id, items)
        if not ok:
            log.info("[TELEGRAM] Álbum falló; se envían uno por uno.")
    if not ok:
        ok = _send_individually(token, chat_id, items)

    if ok:
        log.info("[TELEGRAM] Slides enviados correctamente.")
        return "sent"
    log.warning("[TELEGRAM] No se pudieron enviar los slides.")
    return "error"


# --------------------------------------------------------------------------- #
def _send_album(token: str, chat_id: str, items: list[tuple[Path, str]]) -> bool:
    """Envía hasta 10 fotos por álbum (sendMediaGroup)."""
    try:
        all_ok = True
        # Telegram limita a 10 medios por grupo
        for batch_start in range(0, len(items), 10):
            batch = items[batch_start:batch_start + 10]
            media = []
            files = {}
            handles = []
            for j, (path, cap) in enumerate(batch):
                key = f"photo{j}"
                fh = open(path, "rb")
                handles.append(fh)
                files[key] = fh
                media.append({"type": "photo", "media": f"attach://{key}",
                              "caption": cap, "parse_mode": "HTML"})
            try:
                resp = requests.post(
                    API.format(token=token, method="sendMediaGroup"),
                    data={"chat_id": chat_id, "media": json.dumps(media)},
                    files=files, timeout=60,
                )
            finally:
                for fh in handles:
                    try:
                        fh.close()
                    except Exception:
                        pass
            if not (resp.ok and resp.json().get("ok")):
                log.debug(f"sendMediaGroup respuesta: {resp.status_code} {resp.text[:200]}")
                all_ok = False
        return all_ok
    except Exception as exc:
        log.debug(f"Excepción en sendMediaGroup: {exc}")
        return False


def _send_individually(token: str, chat_id: str, items: list[tuple[Path, str]]) -> bool:
    """Fallback: una foto por mensaje (sendPhoto)."""
    sent = 0
    for path, cap in items:
        try:
            with open(path, "rb") as fh:
                resp = requests.post(
                    API.format(token=token, method="sendPhoto"),
                    data={"chat_id": chat_id, "caption": cap, "parse_mode": "HTML"},
                    files={"photo": fh}, timeout=60,
                )
            if resp.ok and resp.json().get("ok"):
                sent += 1
            else:
                log.debug(f"sendPhoto respuesta: {resp.status_code} {resp.text[:200]}")
        except Exception as exc:
            log.debug(f"Excepción en sendPhoto: {exc}")
    return sent > 0

~~~~

### src\topic_filter.py

~~~~python
"""topic_filter.py — filtro temático OBLIGATORIO de Tecnología / IA.

Se aplica ANTES del ranking y ANTES de guardar/exportar. Si una noticia no es
de tecnología/IA, no entra: no se guarda en SQLite ni se genera su slide.

Función principal:
    is_valid_tech_ai_news(article, config) -> (bool, reason, score)
        bool   : si la noticia es válida (tecnología/IA)
        reason : "accepted" | "not_tech" | "political_general"
        score  : puntaje temático

Reglas:
  1. Necesita al menos `min_topic_score` para aceptarse.
  2. Si hay palabras negativas fuertes y no hay núcleo tech/IA suficiente → rechazo.
  3. Si el título no tiene nada tech/IA, se revisa resumen + tags + metadata.
  4. Si aun así no se detecta tecnología/IA → rechazo.
  5. Se puede aceptar política/regulación SOLO si está ligada a IA/tecnología
     (porque entonces aparecen términos núcleo como "inteligencia artificial",
     "chip", "ciberseguridad", etc., y el score supera el umbral).

La política, economía general, crimen, deportes, farándula, etc., se descartan.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Any, Optional

from .utils import get_logger

log = get_logger()


# --------------------------------------------------------------------------- #
# Listas por defecto (se pueden sobreescribir desde settings.yaml -> topic_filter)
# --------------------------------------------------------------------------- #
DEFAULT_POSITIVE = [
    "inteligencia artificial", "ia", "ai", "artificial intelligence",
    "machine learning", "deep learning", "modelo de ia", "modelos de ia",
    "language model", "llm", "chatbot", "robot", "robotica", "robotics",
    "tecnologia", "tech", "software", "hardware", "chip", "chips",
    "semiconductor", "nvidia", "openai", "google ai", "gemini", "anthropic",
    "claude", "microsoft", "apple intelligence", "samsung", "tesla", "spacex",
    "computacion cuantica", "quantum computing", "ciberseguridad",
    "cybersecurity", "realidad virtual", "realidad aumentada",
    "startup tecnologica", "automatizacion", "automation", "dispositivo inteligente",
    "wearable", "smartphone", "app", "data center", "gpu", "robot humanoide",
    "humanoide", "innovacion tecnologica", "algoritmo", "neural", "deepmind",
]

# Términos "núcleo": confirman tecnología/IA de forma fuerte (cuentan doble).
DEFAULT_CORE = [
    "inteligencia artificial", "artificial intelligence", "machine learning",
    "deep learning", "openai", "anthropic", "claude", "gemini", "chatgpt",
    "llm", "modelo de ia", "nvidia", "gpu", "chip", "chips", "semiconductor",
    "robot", "robotica", "robotics", "computacion cuantica", "quantum computing",
    "ciberseguridad", "cybersecurity", "ia", "ai", "humanoide", "deepmind",
]

DEFAULT_NEGATIVE = [
    "elecciones", "presidente", "gobierno", "congreso", "partido politico",
    "campana electoral", "crimen", "asesinato", "guerra", "conflicto armado",
    "deporte", "deportes", "futbol", "farandula", "celebridad", "religion",
    "escandalo politico", "bolsa de valores", "inflacion",
]

# Tokens cortos que requieren límite de palabra para evitar falsos positivos
# (p. ej. "ai" dentro de "aire", "app" dentro de "appliance").
SHORT_TOKENS = {"ia", "ai", "app", "gpu", "vr", "ar", "tech"}


# --------------------------------------------------------------------------- #
def _strip(text: str) -> str:
    """minúsculas + sin acentos (para comparar con keywords normalizadas)."""
    if not text:
        return ""
    txt = unicodedata.normalize("NFKD", text)
    txt = "".join(c for c in txt if not unicodedata.combining(c))
    return txt.lower()


def _matches(text_norm: str, kw_norm: str) -> bool:
    if not kw_norm:
        return False
    if kw_norm in SHORT_TOKENS or (len(kw_norm) <= 3 and " " not in kw_norm):
        return re.search(rf"(?<![\w]){re.escape(kw_norm)}(?![\w])", text_norm) is not None
    return kw_norm in text_norm


def _found(text_norm: str, keywords: list[str]) -> list[str]:
    out = []
    for kw in keywords:
        kwn = _strip(kw)
        if _matches(text_norm, kwn):
            out.append(kwn)
    return sorted(set(out))


def _article_text(article: dict) -> str:
    """Concatena todos los campos relevantes para el análisis temático."""
    parts: list[str] = []
    for key in ("title_original", "title_es", "summary_original", "summary_es",
                "short_headline_es", "short_caption_es", "region", "country",
                "source_name", "article_url", "canonical_url", "topic"):
        val = article.get(key)
        if val:
            parts.append(str(val))
    # tags / metadata opcionales
    tags = article.get("tags")
    if isinstance(tags, (list, tuple)):
        parts.extend(str(t) for t in tags)
    elif tags:
        parts.append(str(tags))
    meta = article.get("metadata")
    if isinstance(meta, dict):
        parts.extend(str(v) for v in meta.values())
    return _strip(" \n ".join(parts))


# --------------------------------------------------------------------------- #
def is_valid_tech_ai_news(article: dict,
                          config: Optional[dict] = None) -> tuple[bool, str, int]:
    """Filtro temático duro. Devuelve (es_valida, reason, topic_score).

    reason ∈ {"accepted", "not_tech", "political_general", "disabled"}.
    """
    cfg = config or {}
    if not cfg.get("enabled", True):
        return True, "disabled", 0

    min_score = int(cfg.get("min_topic_score", 2))
    positive = cfg.get("positive_keywords") or DEFAULT_POSITIVE
    negative = cfg.get("negative_keywords") or DEFAULT_NEGATIVE
    core = cfg.get("core_keywords") or DEFAULT_CORE

    text = _article_text(article)
    title_norm = _strip(f"{article.get('title_original','')} {article.get('title_es','')}")

    pos_found = _found(text, positive)
    core_found = _found(text, core)
    neg_found = _found(text, negative)

    # Núcleo cuenta doble: confirma con fuerza el tema tech/IA.
    topic_score = len(pos_found) + len(core_found)

    # Regla 3/4: si el título no tiene nada tech, exigimos que el núcleo aparezca
    # en algún lado (resumen/tags); si no hay núcleo ni positivos → no es tech.
    title_has_tech = bool(_found(title_norm, positive))

    accepted = (topic_score >= min_score) and (not neg_found or bool(core_found))
    # Si el título no es tech pero el cuerpo sí tiene núcleo, se permite (regla 3).
    if accepted and not title_has_tech and not core_found:
        accepted = False

    if accepted:
        return True, "accepted", topic_score

    # Rechazo: clasificar el motivo para el resumen.
    if neg_found:
        return False, "political_general", topic_score
    return False, "not_tech", topic_score


def log_decision(article: dict, valid: bool, reason: str, score: int) -> None:
    """Loguea la decisión con las etiquetas pedidas."""
    title = (article.get("title_original") or article.get("title_es") or "")[:70]
    if valid:
        log.info(f"[green][ACEPTADA TECH/IA][/] (t{score}) {title}")
    elif reason == "political_general":
        log.info(f"[red][RECHAZADA POLÍTICA][/] (t{score}) {title}")
    else:
        log.info(f"[yellow][RECHAZADA NO TECH][/] (t{score}) {title}")

~~~~

### src\translator.py

~~~~python
"""translator.py — traducción modular al español.

Diseño:
  - Si hay una API configurada (DeepL o Google) en settings.yaml, se usa.
  - Si no, se intenta deep-translator (GoogleTranslator gratuito).
  - Si nada está disponible, se devuelve el texto original (fallback "none")
    marcando que no se tradujo, pero el programa NO se detiene.

La detección de idioma usa langdetect. El video se deja en su idioma original;
solo se traducen título y descripción.
"""
from __future__ import annotations

from typing import Optional

from .utils import get_logger

log = get_logger()


def detect_language(text: str) -> str:
    """Detecta el idioma de un texto (código ISO-639-1) o 'und' si falla."""
    if not text or len(text.strip()) < 3:
        return "und"
    try:
        from langdetect import detect, DetectorFactory
        DetectorFactory.seed = 0
        return detect(text)
    except Exception:
        return "und"


class Translator:
    """Traductor con backend intercambiable."""

    def __init__(self, settings: dict):
        tr = (settings or {}).get("translation", {})
        self.target = tr.get("target_language", "es")
        self.backend_pref = tr.get("backend", "auto")
        api = tr.get("api", {}) or {}
        self.api_provider = (api.get("provider") or "").lower()
        self.api_key = api.get("api_key") or ""

        self._engine = None          # callable(text, src, dest) -> str
        self._backend_name = "none"
        self._init_backend()

    # ------------------------------------------------------------------ #
    def _init_backend(self) -> None:
        pref = self.backend_pref

        if pref == "none":
            self._backend_name = "none"
            return

        # 1) API explícita
        if self.api_provider == "deepl" and self.api_key:
            if self._try_deepl():
                return
        if self.api_provider == "google" and self.api_key:
            if self._try_google_cloud():
                return

        # 2) deep-translator (gratuito) como fallback
        if pref in ("auto", "deep_translator"):
            if self._try_deep_translator():
                return

        self._backend_name = "none"
        log.warning("[yellow]No hay backend de traducción disponible. "
                    "Los textos se guardarán en su idioma original.[/]")

    def _try_deepl(self) -> bool:
        try:
            import deepl  # type: ignore
            translator = deepl.Translator(self.api_key)

            def engine(text: str, src: str, dest: str) -> str:
                res = translator.translate_text(text, target_lang="ES")
                return str(res)

            self._engine = engine
            self._backend_name = "deepl"
            log.info("Traducción: usando API DeepL")
            return True
        except Exception as exc:
            log.debug(f"DeepL no disponible: {exc}")
            return False

    def _try_google_cloud(self) -> bool:
        try:
            from google.cloud import translate_v2 as gtranslate  # type: ignore
            client = gtranslate.Client()

            def engine(text: str, src: str, dest: str) -> str:
                res = client.translate(text, target_language=dest)
                return res["translatedText"]

            self._engine = engine
            self._backend_name = "google_cloud"
            log.info("Traducción: usando API Google Cloud Translation")
            return True
        except Exception as exc:
            log.debug(f"Google Cloud Translate no disponible: {exc}")
            return False

    def _try_deep_translator(self) -> bool:
        try:
            from deep_translator import GoogleTranslator

            def engine(text: str, src: str, dest: str) -> str:
                source = src if src and src != "und" else "auto"
                return GoogleTranslator(source=source, target=dest).translate(text)

            self._engine = engine
            self._backend_name = "deep_translator"
            log.info("Traducción: usando deep-translator (GoogleTranslator gratuito)")
            return True
        except Exception as exc:
            log.debug(f"deep-translator no disponible: {exc}")
            return False

    # ------------------------------------------------------------------ #
    @property
    def backend(self) -> str:
        return self._backend_name

    def translate(self, text: str, src_lang: str = "auto") -> str:
        """Traduce 'text' al idioma destino. Si no se puede, devuelve el original."""
        if not text or not text.strip():
            return text
        # Si ya está en el idioma destino, no traducir.
        if src_lang and src_lang.startswith(self.target):
            return text
        if not self._engine:
            return text
        try:
            # deep-translator/algunas APIs tienen límites por longitud; troceamos.
            if len(text) > 4500:
                parts = _chunk(text, 4500)
                return " ".join(self._safe(p, src_lang) for p in parts)
            return self._safe(text, src_lang)
        except Exception as exc:
            log.debug(f"Fallo de traducción, se mantiene original: {exc}")
            return text

    def _safe(self, text: str, src_lang: str) -> str:
        try:
            out = self._engine(text, src_lang, self.target)
            return out or text
        except Exception:
            return text


def _chunk(text: str, size: int) -> list[str]:
    return [text[i:i + size] for i in range(0, len(text), size)]

~~~~

### src\utils.py

~~~~python
"""utils.py — utilidades compartidas.

Incluye:
  - Carga de YAML de configuración.
  - Logging con rich (consola bonita) y fallback a logging estándar.
  - Hashing y normalización de títulos / URLs (para deduplicación).
  - Parsing flexible de fechas.
  - Helpers de URL (canonicalización).
"""
from __future__ import annotations

import hashlib
import logging
import re
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse, urlunparse, parse_qsl, urlencode

import yaml

try:  # rich es opcional pero recomendado
    from rich.console import Console
    from rich.logging import RichHandler
    _HAS_RICH = True
    console = Console()
except Exception:  # pragma: no cover
    _HAS_RICH = False
    console = None


# --------------------------------------------------------------------------- #
# Configuración / logging
# --------------------------------------------------------------------------- #
def load_yaml(path: str | Path) -> dict[str, Any]:
    """Carga un archivo YAML y devuelve un dict (vacío si no existe)."""
    p = Path(path)
    if not p.exists():
        return {}
    with p.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    return data or {}


def setup_logging(level: str = "INFO") -> logging.Logger:
    """Configura el logger raíz del proyecto."""
    lvl = getattr(logging, str(level).upper(), logging.INFO)
    logger = logging.getLogger("tnvs")
    logger.setLevel(lvl)
    logger.handlers.clear()

    if _HAS_RICH:
        handler: logging.Handler = RichHandler(
            console=console, rich_tracebacks=True, show_path=False, markup=True
        )
        fmt = "%(message)s"
    else:
        handler = logging.StreamHandler()
        fmt = "%(asctime)s [%(levelname)s] %(message)s"

    handler.setFormatter(logging.Formatter(fmt, datefmt="%H:%M:%S"))
    logger.addHandler(handler)
    logger.propagate = False
    return logger


def get_logger() -> logging.Logger:
    return logging.getLogger("tnvs")


# --------------------------------------------------------------------------- #
# Normalización y hashing
# --------------------------------------------------------------------------- #
def normalize_title(title: str) -> str:
    """Normaliza un título para comparar duplicados.

    - minúsculas
    - sin acentos
    - sin signos de puntuación
    - espacios colapsados
    """
    if not title:
        return ""
    txt = unicodedata.normalize("NFKD", title)
    txt = "".join(c for c in txt if not unicodedata.combining(c))
    txt = txt.lower()
    txt = re.sub(r"[^a-z0-9\s]", " ", txt)
    txt = re.sub(r"\s+", " ", txt).strip()
    return txt


def title_hash(title: str) -> str:
    """Hash estable del título normalizado (para deduplicar)."""
    return hashlib.sha256(normalize_title(title).encode("utf-8")).hexdigest()


def content_hash(*parts: str) -> str:
    """Hash de contenido a partir de varias piezas (título + url + video...)."""
    joined = "||".join(normalize_title(p) if p else "" for p in parts)
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------- #
# URLs
# --------------------------------------------------------------------------- #
_TRACKING_PARAMS = {
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "utm_id", "fbclid", "gclid", "mc_cid", "mc_eid", "igshid", "ref", "cmpid",
    "ito", "at_medium", "at_campaign",
}


def canonical_url(url: str) -> str:
    """Devuelve una versión canónica/limpia de la URL.

    - quita parámetros de tracking
    - quita fragmento (#...)
    - normaliza esquema y host en minúsculas
    - elimina barra final redundante
    """
    if not url:
        return ""
    try:
        parsed = urlparse(url.strip())
    except Exception:
        return url.strip()

    scheme = (parsed.scheme or "https").lower()
    netloc = parsed.netloc.lower()
    path = parsed.path or "/"
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")

    query_pairs = [
        (k, v) for k, v in parse_qsl(parsed.query, keep_blank_values=False)
        if k.lower() not in _TRACKING_PARAMS
    ]
    query = urlencode(query_pairs)

    return urlunparse((scheme, netloc, path, "", query, ""))


def domain_of(url: str) -> str:
    try:
        return urlparse(url).netloc.lower().replace("www.", "")
    except Exception:
        return ""


def absolutize(base_url: str, maybe_relative: str) -> str:
    """Convierte una URL relativa en absoluta respecto a base_url."""
    from urllib.parse import urljoin
    if not maybe_relative:
        return ""
    return urljoin(base_url, maybe_relative)


# --------------------------------------------------------------------------- #
# Fechas
# --------------------------------------------------------------------------- #
def parse_date(value: Optional[str]) -> Optional[datetime]:
    """Parsea una fecha en muchos formatos. Devuelve datetime con tz UTC o None."""
    if not value:
        return None
    value = value.strip()
    try:
        from dateutil import parser as dateparser
        dt = dateparser.parse(value)
        if dt is None:
            return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


def age_in_days(dt: Optional[datetime]) -> Optional[float]:
    if not dt:
        return None
    return (now_utc() - dt).total_seconds() / 86400.0


def run_timestamp() -> str:
    """Marca de tiempo para nombre de carpeta: YYYY-MM-DD_HH-mm-ss."""
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

~~~~

### src\video_detector.py

~~~~python
"""video_detector.py — detección de video dentro del HTML de una noticia.

Estrategias (en orden de fiabilidad):
  1. JSON-LD VideoObject (schema.org)
  2. Open Graph de video (og:video, og:video:url, twitter:player)
  3. <video> nativo (HTML5) con <source>
  4. <iframe> de reproductores (YouTube, Vimeo, Dailymotion, JW, etc.)
  5. Enlaces <a> claramente asociados a un video

Devuelve un VideoInfo. NO descarga el video: solo extrae enlaces/embeds
públicos, respetando copyright y DRM.
"""
from __future__ import annotations

import json
import re
from typing import Optional

from bs4 import BeautifulSoup

from .models import VideoInfo
from .utils import absolutize, get_logger

log = get_logger()


# Dominios de reproductores conocidos -> tipo
_PLAYER_PATTERNS = {
    "youtube": [r"youtube\.com/embed/", r"youtube\.com/watch", r"youtu\.be/",
                r"youtube-nocookie\.com/embed/"],
    "vimeo": [r"player\.vimeo\.com/video/", r"vimeo\.com/\d+"],
    "dailymotion": [r"dailymotion\.com/embed/", r"dai\.ly/", r"dailymotion\.com/video/"],
    "jwplayer": [r"cdn\.jwplayer\.com/", r"content\.jwplatform\.com/"],
    "brightcove": [r"players\.brightcove\.net/"],
    "twitch": [r"player\.twitch\.tv/"],
    "facebook": [r"facebook\.com/plugins/video", r"fb\.watch/"],
}

# Embeds que en realidad son publicidad / redes / no-video → ignorar
_IGNORE_IFRAME = [
    r"doubleclick", r"googlesyndication", r"adservice", r"taboola",
    r"outbrain", r"disqus", r"/ads/", r"newsletter", r"consent", r"captcha",
]


def _match_player(url: str) -> Optional[str]:
    low = url.lower()
    for vtype, patterns in _PLAYER_PATTERNS.items():
        for pat in patterns:
            if re.search(pat, low):
                return vtype
    return None


def _youtube_embed(url: str) -> str:
    """Normaliza una URL de YouTube a su forma /embed/."""
    m = re.search(r"(?:v=|youtu\.be/|embed/)([A-Za-z0-9_\-]{6,})", url)
    if m:
        return f"https://www.youtube.com/embed/{m.group(1)}"
    return url


def _vimeo_embed(url: str) -> str:
    m = re.search(r"vimeo\.com/(?:video/)?(\d+)", url)
    if m:
        return f"https://player.vimeo.com/video/{m.group(1)}"
    return url


def _normalize_embed(vtype: str, url: str) -> str:
    if vtype == "youtube":
        return _youtube_embed(url)
    if vtype == "vimeo":
        return _vimeo_embed(url)
    return url


# --------------------------------------------------------------------------- #
def _from_jsonld(soup: BeautifulSoup, base_url: str) -> Optional[VideoInfo]:
    for tag in soup.find_all("script", type="application/ld+json"):
        if not tag.string:
            continue
        try:
            data = json.loads(tag.string)
        except Exception:
            # algunos sitios meten varios objetos JSON o JSON inválido
            try:
                data = json.loads(re.sub(r",\s*}", "}", tag.string))
            except Exception:
                continue
        for obj in _iter_jsonld_objects(data):
            t = obj.get("@type", "")
            types = t if isinstance(t, list) else [t]
            if any("VideoObject" in str(x) for x in types):
                content = (obj.get("contentUrl") or obj.get("embedUrl")
                           or obj.get("url") or "")
                embed = obj.get("embedUrl") or content
                if content or embed:
                    vtype = _match_player(content or embed) or "jsonld"
                    return VideoInfo(
                        found=True,
                        video_type=vtype,
                        video_url=absolutize(base_url, content or embed),
                        video_embed_url=_normalize_embed(
                            vtype, absolutize(base_url, embed or content)),
                        related=True,
                    )
    return None


def _iter_jsonld_objects(data):
    if isinstance(data, dict):
        if "@graph" in data and isinstance(data["@graph"], list):
            for item in data["@graph"]:
                yield from _iter_jsonld_objects(item)
        yield data
    elif isinstance(data, list):
        for item in data:
            yield from _iter_jsonld_objects(item)


def _from_opengraph(soup: BeautifulSoup, base_url: str) -> Optional[VideoInfo]:
    candidates = []
    for prop in ("og:video:url", "og:video:secure_url", "og:video", "twitter:player"):
        for tag in soup.find_all("meta", attrs={"property": prop}):
            if tag.get("content"):
                candidates.append(tag["content"])
        for tag in soup.find_all("meta", attrs={"name": prop}):
            if tag.get("content"):
                candidates.append(tag["content"])

    for url in candidates:
        if not url:
            continue
        abs_url = absolutize(base_url, url)
        vtype = _match_player(abs_url) or "og_video"
        return VideoInfo(
            found=True,
            video_type=vtype,
            video_url=abs_url,
            video_embed_url=_normalize_embed(vtype, abs_url),
            related=True,
        )
    return None


def _from_html5_video(soup: BeautifulSoup, base_url: str) -> Optional[VideoInfo]:
    for video in soup.find_all("video"):
        src = video.get("src")
        if not src:
            source = video.find("source")
            if source and source.get("src"):
                src = source["src"]
        if src:
            abs_url = absolutize(base_url, src)
            return VideoInfo(
                found=True,
                video_type="html5",
                video_url=abs_url,
                video_embed_url=abs_url,
                related=True,
            )
    return None


def _from_iframes(soup: BeautifulSoup, base_url: str) -> Optional[VideoInfo]:
    for iframe in soup.find_all("iframe"):
        src = iframe.get("src") or iframe.get("data-src") or ""
        if not src:
            continue
        low = src.lower()
        if any(re.search(p, low) for p in _IGNORE_IFRAME):
            continue
        vtype = _match_player(src)
        if vtype:
            abs_url = absolutize(base_url, src)
            return VideoInfo(
                found=True,
                video_type=vtype,
                video_url=abs_url,
                video_embed_url=_normalize_embed(vtype, abs_url),
                related=True,
            )
    return None


def _from_links(soup: BeautifulSoup, base_url: str) -> Optional[VideoInfo]:
    for a in soup.find_all("a", href=True):
        href = a["href"]
        vtype = _match_player(href)
        if vtype:
            abs_url = absolutize(base_url, href)
            # Heurística de relación: enlaces dentro del artículo se consideran
            # relacionados; aun así marcamos related=True por defecto.
            return VideoInfo(
                found=True,
                video_type=vtype,
                video_url=abs_url,
                video_embed_url=_normalize_embed(vtype, abs_url),
                related=True,
            )
    return None


# --------------------------------------------------------------------------- #
def detect_video(html: str, base_url: str, accept_types: list[str] | None = None) -> VideoInfo:
    """Analiza el HTML de un artículo y devuelve VideoInfo.

    accept_types: lista de tipos aceptados (de settings.yaml). Si un video
    detectado no está en la lista, se considera no encontrado.
    """
    if not html:
        return VideoInfo(found=False)

    soup = BeautifulSoup(html, "html.parser")

    for strategy in (_from_jsonld, _from_opengraph, _from_html5_video,
                     _from_iframes, _from_links):
        try:
            info = strategy(soup, base_url)
        except Exception as exc:  # nunca dejar que un sitio raro rompa todo
            log.debug(f"Estrategia {strategy.__name__} falló: {exc}")
            info = None
        if info and info.found:
            if accept_types and info.video_type not in accept_types:
                # tipo detectado no aceptado; seguimos probando otras estrategias
                continue
            return info

    return VideoInfo(found=False)

~~~~

### templates\card.html

~~~~html
<!DOCTYPE html>
<!--
  card.html — plantilla de tarjeta vertical para redes sociales.
  Estructura pedida:
    - Parte SUPERIOR: descripción corta de la noticia en español.
    - Parte INFERIOR: video embebido / reproductor.
  Pensada para capturarla o convertirla en imagen/video vertical (9:16).
  Variables Jinja2: title_es, summary_es, source_name, region, published,
                    article_url, video_embed_url, video_url, video_type,
                    carousel_text.
-->
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ title_es }}</title>
  <style>
    :root {
      --bg: #0b1020;
      --card: #121a33;
      --accent: #4f8cff;
      --text: #f5f7fb;
      --muted: #9fb0d0;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      background: var(--bg);
      color: var(--text);
      font-family: "Segoe UI", Roboto, system-ui, -apple-system, sans-serif;
    }
    .frame {
      width: 1080px;
      max-width: 100%;
      min-height: 1920px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      background: linear-gradient(160deg, #0b1020 0%, #131c3a 100%);
    }
    /* ----- PARTE SUPERIOR: descripción ----- */
    .top {
      flex: 0 0 auto;
      padding: 64px 64px 40px 64px;
    }
    .badge {
      display: inline-block;
      background: var(--accent);
      color: #fff;
      font-size: 28px;
      font-weight: 700;
      letter-spacing: .5px;
      padding: 10px 22px;
      border-radius: 999px;
      margin-bottom: 32px;
    }
    .headline {
      font-size: 64px;
      line-height: 1.15;
      font-weight: 800;
      margin-bottom: 28px;
    }
    .summary {
      font-size: 40px;
      line-height: 1.35;
      color: var(--text);
    }
    .carousel-text {
      margin-top: 28px;
      font-size: 34px;
      line-height: 1.3;
      color: var(--muted);
      border-left: 6px solid var(--accent);
      padding-left: 24px;
    }
    /* ----- PARTE INFERIOR: video ----- */
    .bottom {
      flex: 1 1 auto;
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 24px 64px 48px 64px;
    }
    .video-wrap {
      position: relative;
      width: 100%;
      padding-top: 56.25%; /* 16:9 */
      background: #000;
      border-radius: 24px;
      overflow: hidden;
      box-shadow: 0 20px 60px rgba(0,0,0,.5);
    }
    .video-wrap iframe,
    .video-wrap video {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      border: 0;
    }
    .no-video {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--muted);
      font-size: 32px;
      text-align: center;
      padding: 0 40px;
    }
    /* ----- pie ----- */
    .meta {
      margin-top: 36px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 30px;
      color: var(--muted);
    }
    .meta a { color: var(--accent); text-decoration: none; word-break: break-all; }
    .source { font-weight: 700; color: var(--text); }
  </style>
</head>
<body>
  <div class="frame">
    <div class="top">
      <span class="badge">Tecnología · IA</span>
      {% if title_es %}<h1 class="headline">{{ title_es }}</h1>{% endif %}
      {% if summary_es %}<p class="summary">{{ summary_es }}</p>{% endif %}
      {% if carousel_text %}<p class="carousel-text">{{ carousel_text }}</p>{% endif %}
    </div>

    <div class="bottom">
      <div class="video-wrap">
        {% if video_embed_url and video_type in ['youtube','vimeo','dailymotion','jwplayer','brightcove','twitch','facebook','iframe','og_video','jsonld'] %}
          <iframe src="{{ video_embed_url }}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy"></iframe>
        {% elif video_url and video_type == 'html5' %}
          <video controls preload="metadata" src="{{ video_url }}"></video>
        {% elif video_url %}
          <iframe src="{{ video_url }}" allowfullscreen loading="lazy"></iframe>
        {% else %}
          <div class="no-video">Sin video embebible. Enlace original arriba.</div>
        {% endif %}
      </div>

      <div class="meta">
        <span class="source">{{ source_name }}{% if region %} · {{ region }}{% endif %}</span>
        <span>{{ published or '' }}</span>
      </div>
      {% if article_url %}
      <div class="meta">
        <a href="{{ article_url }}">{{ article_url }}</a>
      </div>
      {% endif %}
    </div>
  </div>
</body>
</html>

~~~~

### templates\card_template.html

~~~~html
<!DOCTYPE html>
<!--
  card_template.html — SLIDE vertical 1080x1350 para carrusel de Instagram.
  Estilo: tecnológico/premium. Imagen de fondo + degradado oscuro + titular en
  MAYÚSCULAS con palabras clave en violeta + descripción + footer.
  Este HTML es el que Playwright captura como slide.png.
  Variables: headline_html (seguro), caption, source_name, date, category,
             image_data_uri (data: o file:// o url), has_image (bool).
-->
<html lang="es">
<head>
<meta charset="utf-8">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800;900&display=swap');
  * { margin:0; padding:0; box-sizing:border-box; }
  html, body { width:1080px; height:1350px; }
  body {
    font-family:'Inter', "Segoe UI", Roboto, system-ui, sans-serif;
    background:#0a0e1a;
    overflow:hidden;
  }
  .slide {
    position:relative;
    width:1080px;
    height:1350px;
    overflow:hidden;
    background:
      radial-gradient(1200px 800px at 80% -10%, #2a1c5e 0%, rgba(42,28,94,0) 55%),
      linear-gradient(160deg, #0d1226 0%, #0a0e1a 60%, #070a14 100%);
  }
  /* ---- Imagen principal (mitad superior, full-bleed) ---- */
  .hero {
    position:absolute; top:0; left:0; right:0;
    height:760px;
    background-size:cover;
    background-position:center;
    background-repeat:no-repeat;
  }
  .hero.no-image {
    background:
      radial-gradient(900px 500px at 25% 20%, #3b2a7a 0%, rgba(59,42,122,0) 60%),
      radial-gradient(700px 500px at 90% 30%, #1d4ed8 0%, rgba(29,78,216,0) 55%),
      linear-gradient(135deg, #131a35 0%, #0a0e1a 100%);
  }
  /* Degradado oscuro para contraste del texto */
  .scrim {
    position:absolute; left:0; right:0; bottom:0; top:0;
    background:linear-gradient(180deg,
      rgba(8,11,22,0.05) 0%,
      rgba(8,11,22,0.25) 38%,
      rgba(8,11,22,0.86) 62%,
      rgba(8,11,22,0.98) 100%);
  }
  /* ---- Marca / categoría ---- */
  .topbar {
    position:absolute; top:54px; left:64px; right:64px;
    display:flex; align-items:center; justify-content:space-between; z-index:3;
  }
  .brand {
    display:flex; align-items:center; gap:14px;
    color:#fff; font-weight:800; font-size:30px; letter-spacing:.5px;
  }
  .brand .dot {
    width:18px; height:18px; border-radius:50%;
    background:linear-gradient(135deg,#7c3aed,#4f46e5);
    box-shadow:0 0 22px rgba(124,58,237,.9);
  }
  .pill {
    background:rgba(124,58,237,.18);
    border:1.5px solid rgba(167,139,250,.55);
    color:#c4b5fd; font-weight:700; font-size:24px;
    padding:10px 22px; border-radius:999px; backdrop-filter:blur(4px);
  }
  /* ---- Bloque de texto inferior ---- */
  .content {
    position:absolute; left:64px; right:64px; bottom:64px; z-index:3;
  }
  .headline {
    color:#ffffff;
    font-weight:900;
    text-transform:uppercase;
    font-size:{{ headline_size or 78 }}px;
    line-height:1.04;
    letter-spacing:-0.5px;
    text-shadow:0 4px 30px rgba(0,0,0,.55);
    margin-bottom:26px;
  }
  .headline .hl { color:#a78bfa; }   /* palabras clave en violeta */
  .caption {
    color:#d7def0;
    font-weight:400;
    font-size:36px;
    line-height:1.34;
    margin-bottom:34px;
    max-height:200px;
    overflow:hidden;
  }
  .footer {
    display:flex; align-items:center; justify-content:space-between;
    border-top:1.5px solid rgba(255,255,255,.14);
    padding-top:24px;
  }
  .source {
    display:flex; align-items:center; gap:14px;
    color:#fff; font-weight:700; font-size:30px;
  }
  .source .play {
    width:42px; height:42px; border-radius:50%;
    background:linear-gradient(135deg,#7c3aed,#4f46e5);
    display:flex; align-items:center; justify-content:center;
  }
  .source .play svg { width:18px; height:18px; fill:#fff; }
  .date { color:#9fb0d0; font-size:28px; font-weight:600; }
  .badge-media {
    position:absolute; top:54px; right:64px;
  }
</style>
</head>
<body>
  <div class="slide">
    <div class="hero {% if not has_image %}no-image{% endif %}"
         {% if has_image %}style="background-image:url('{{ image_data_uri }}')"{% endif %}></div>
    <div class="scrim"></div>

    <div class="topbar">
      <div class="brand"><span class="dot"></span> TECH&nbsp;·&nbsp;IA</div>
      {% if category %}<div class="pill">{{ category }}</div>{% endif %}
    </div>

    <div class="content">
      <div class="headline">{{ headline_html | safe }}</div>
      {% if caption %}<div class="caption">{{ caption }}</div>{% endif %}
      <div class="footer">
        <div class="source">
          {% if media_type == 'video' %}
          <span class="play"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></span>
          {% endif %}
          {{ source_name }}
        </div>
        <div class="date">{{ date }}</div>
      </div>
    </div>
  </div>
</body>
</html>

~~~~

### templates\embed_template.html

~~~~html
<!DOCTYPE html>
<!--
  embed_template.html — reproductor del video con descripción arriba.
  Caso A (embed_status == ok): muestra el reproductor embebido.
  Caso B (blocked): muestra el poster + botón "Ver en la fuente" (no se puede
  embeber por restricciones del sitio; no fallamos).
  Variables: title, caption, embed_status, video_embed_url, video_url,
             video_type, poster_data_uri, article_url, source_name.
-->
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ title }}</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{background:#0a0e1a;color:#fff;font-family:'Segoe UI',system-ui,sans-serif}
    .wrap{max-width:1000px;margin:0 auto;padding:24px}
    .desc{font-size:22px;line-height:1.4;padding:18px 22px;background:#121a33;
          border-radius:14px;margin-bottom:18px}
    .desc small{color:#9fb0d0;display:block;margin-top:8px;font-size:16px}
    .v{position:relative;width:100%;padding-top:56.25%;background:#000;
       border-radius:16px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.5)}
    .v>iframe,.v>video{position:absolute;inset:0;width:100%;height:100%;border:0}
    .poster{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
    .blocked{position:absolute;inset:0;display:flex;flex-direction:column;
             align-items:center;justify-content:center;text-align:center;
             background:rgba(8,11,22,.55)}
    .btn{display:inline-block;margin-top:16px;background:linear-gradient(135deg,#7c3aed,#4f46e5);
         color:#fff;text-decoration:none;font-weight:700;font-size:20px;
         padding:14px 28px;border-radius:999px}
    .note{margin-top:10px;color:#cbd5e1;font-size:15px}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="desc">
      {{ caption or title }}
      <small>{{ source_name }}{% if video_type %} · video: {{ video_type }}{% endif %}</small>
    </div>
    <div class="v">
      {% if embed_status == 'ok' and video_type == 'html5' and video_url %}
        <video controls preload="metadata" {% if poster_data_uri %}poster="{{ poster_data_uri }}"{% endif %} src="{{ video_url }}"></video>
      {% elif embed_status == 'ok' and video_embed_url %}
        <iframe src="{{ video_embed_url }}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy"></iframe>
      {% else %}
        {% if poster_data_uri %}<img class="poster" src="{{ poster_data_uri }}" alt="poster">{% endif %}
        <div class="blocked">
          <div>Este video no se puede embeber aquí{% if embed_status and embed_status != 'none' %} ({{ embed_status }}){% endif %}.</div>
          <a class="btn" href="{{ video_url or article_url }}" target="_blank" rel="noopener">▶ Ver video en la fuente</a>
          <div class="note">Se respetan las restricciones del sitio (sin saltar paywalls/DRM).</div>
        </div>
      {% endif %}
    </div>
  </div>
</body>
</html>

~~~~

### templates\index_template.html

~~~~html
<!DOCTYPE html>
<!--
  index_template.html — galería del run. Muestra las noticias con su slide.png,
  título, fuente y enlaces (artículo, video, embed).
  Variables: run_id, topic, generated_at, items[]
    item: { folder, slide_rel, title, source_name, date, media_type,
            embed_status, article_url, video_url, has_embed, embed_rel }
-->
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Carrusel — {{ topic }}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap');
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:'Inter',system-ui,sans-serif;background:#0a0e1a;color:#eef2ff;padding:40px}
    header{max-width:1200px;margin:0 auto 32px}
    h1{font-size:34px;font-weight:800}
    .sub{color:#9fb0d0;margin-top:8px;font-size:16px}
    .grid{max-width:1200px;margin:0 auto;display:grid;
          grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:26px}
    .card{background:#121a33;border:1px solid #22305c;border-radius:18px;overflow:hidden;
          display:flex;flex-direction:column}
    .thumb{aspect-ratio:4/5;background:#000;overflow:hidden}
    .thumb img{width:100%;height:100%;object-fit:cover;display:block}
    .body{padding:18px;display:flex;flex-direction:column;gap:10px;flex:1}
    .title{font-size:18px;font-weight:700;line-height:1.3}
    .meta{color:#9fb0d0;font-size:14px;display:flex;justify-content:space-between}
    .tags{display:flex;gap:8px;flex-wrap:wrap}
    .tag{font-size:12px;font-weight:700;padding:4px 10px;border-radius:999px}
    .tag.video{background:rgba(124,58,237,.2);color:#c4b5fd}
    .tag.image{background:rgba(29,78,216,.2);color:#93c5fd}
    .tag.blocked{background:rgba(220,38,38,.18);color:#fca5a5}
    .links{display:flex;gap:10px;margin-top:auto;flex-wrap:wrap}
    .links a{font-size:14px;font-weight:600;text-decoration:none;color:#fff;
             background:#1e2a52;padding:9px 14px;border-radius:10px}
    .links a.primary{background:linear-gradient(135deg,#7c3aed,#4f46e5)}
  </style>
</head>
<body>
  <header>
    <h1>Carrusel de noticias — {{ topic }}</h1>
    <div class="sub">Run {{ run_id }} · generado {{ generated_at }} · {{ items|length }} noticias</div>
  </header>
  <div class="grid">
    {% for it in items %}
    <div class="card">
      <div class="thumb"><img src="{{ it.slide_rel }}" alt="slide"></div>
      <div class="body">
        <div class="tags">
          <span class="tag {{ it.media_type }}">{{ it.media_type|upper }}</span>
          {% if it.embed_status == 'blocked' %}<span class="tag blocked">EMBED BLOQUEADO</span>{% endif %}
        </div>
        <div class="title">{{ it.title }}</div>
        <div class="meta"><span>{{ it.source_name }}</span><span>{{ it.date }}</span></div>
        <div class="links">
          <a class="primary" href="{{ it.article_url }}" target="_blank" rel="noopener">Artículo</a>
          {% if it.video_url %}<a href="{{ it.video_url }}" target="_blank" rel="noopener">Video</a>{% endif %}
          {% if it.has_embed %}<a href="{{ it.embed_rel }}" target="_blank">Embed</a>{% endif %}
        </div>
      </div>
    </div>
    {% endfor %}
  </div>
</body>
</html>

~~~~


